"""
190410: Created from another script.
190510: Fixed bug in testing for invalid knot vector.
210109: Now reports knot info when this script is run on its own.

V7 now includes knot type reporting, so isUniform is more useful for V5 & V6.

TODO: Test for invalid knot vector may need more work.
"""

import Rhino


def isUniform(knots):
    
    knots = list(knots)
    
    len_knots = len(knots)
    
    if len_knots == 2:
        return True
    elif len_knots < 2:
        return
    
    bPeriodicOrDeg1 = not Rhino.RhinoMath.EpsilonEquals(
            knots[0], knots[1], Rhino.RhinoMath.ZeroTolerance)
    
    if not bPeriodicOrDeg1 and len_knots > 2:
        if not Rhino.RhinoMath.EpsilonEquals(
                knots[-1], knots[-2], Rhino.RhinoMath.ZeroTolerance
        ):
            print "Knot vector is invalid: {}".format(knots)
            return
    
    knotVect1stSpan = knots[1] - knots[0]
    
    if not bPeriodicOrDeg1:
        for i in xrange(1, len_knots//2):
            if not Rhino.RhinoMath.EpsilonEquals(knots[i] - knots[i+1],
                    knotVect1stSpan,
                    Rhino.RhinoMath.ZeroTolerance):
                break
        else:
            print "Degree cannot be determined."
            return
        
        degree = i + 1
    else:
        degree = 1 # Even if periodic of degree > 1.
    
    # Set up for loop's range's start and stop based on whether knot vector is periodic.
    # iKnot_Start: Start of spans to check.
    # iKnot_End: End of spans to check.
    if bPeriodicOrDeg1:
        iKnot_Start = 0
        iKnot_End = len_knots - 1
        knotVect1stSpan_Not0 = knotVect1stSpan
    else:
        iKnot_Start = degree - 1
        iKnot_End = len_knots - degree
        if iKnot_Start == iKnot_End: return True # Is this also true when periodic?
        knotVect1stSpan_Not0 = knots[degree] - knots[degree-1]
    pass
    #  A uniform knot vector's interior parameter spans are all equal.
    for i in range(iKnot_Start, iKnot_End):
        span = knots[i+1] - knots[i]
        if not Rhino.RhinoMath.EpsilonEquals(
                span,
                knotVect1stSpan_Not0,
                Rhino.RhinoMath.ZeroTolerance):
            return False
    
    return True


def getKnotInfo(knots):
    """Returns a string."""
    i = 0
    iMulties = []
    fKnotTs_Unique = []
    while True:
        knot = knots[i]
        fKnotTs_Unique.append(knot)
        iMulti = knots.KnotMultiplicity(index=i)
        iMulties.append(iMulti)
        #print "{} at {:.4f}".format(iMulti, knot),
        i += iMulti
        if i >= knots.Count:
            break
    s = ""
    s = "Domain:[{:.6f},{:.6f}]".format(fKnotTs_Unique[0], fKnotTs_Unique[-1])
    s += "  Multiplicities:"
    s += ",".join(str(i) for i in iMulties)
    if all(i == 1 for i in iMulties):
        # For periodic.
        s += "  {} uniform".format("Is" if isUniform(knots) else "Not")
    elif len(iMulties[1:-1]) == 0:
        # For Bezier / single span.  Otherwise, the next elif will include it.
        pass
    elif all(i == 1 for i in iMulties[1:-1]):
        s += "  {} uniform".format("Is" if isUniform(knots) else "Not")
    else:
        # For other non-uniform obvious by its list of multiplicies.
        pass
    return s


def main():
    import Rhino.Geometry as rg
    import rhinoscriptsyntax as rs
    import scriptcontext as sc


    gObj = rs.GetObject(
        "Select curve or face",
        filter=rs.filter.curve + rs.filter.surface,
        preselect=True,
        subobjects=True)
    if gObj is None: return


    rgObj = rs.coercegeometry(gObj)
    rgCrv = rs.coercecurve(gObj)
    if rgCrv is None:
        rgF = rs.coercesurface(gObj)
        rgS = rgF.UnderlyingSurface()
        if isinstance(rgS, rg.NurbsSurface):
            ns = rgS
        elif isinstance(rgS, rg.PlaneSurface):
            print "Surface is a PlaneSurface."
            return
        elif isinstance(rgS, rg.RevSurface):
            rgCrv = rg.RevSurface.Curve
            if not isinstance(rgCrv, rg.NurbsCurve):
                print "Surface is a RevSurface with a {} revolute curve."
                return
            ns = rgS.ToNurbsSurface()
        elif isinstance(rgS, rg.SumSurface):
            if rgS.IsCone(sc.doc.ModelAbsoluteTolerance):
                print "Surface is a cone-shaped SumSurface."
                return
            elif rgS.IsCylinder(sc.doc.ModelAbsoluteTolerance):
                print "Surface is a cylindrical SumSurface."
                return
            elif rgS.IsSphere(sc.doc.ModelAbsoluteTolerance):
                print "Surface is a spherical SumSurface."
                return
            elif rgS.IsPlanar(sc.doc.ModelAbsoluteTolerance):
                print "Surface is a planar SumSurface."
                return
            ns = rgS.ToNurbsSurface()
        else:
            print "{} not supported yet".format(rgS.GetType().Name)
            return
        print "KnotsU:{}".format(getKnotInfo(ns.KnotsU))
        print "KnotsV:{}".format(getKnotInfo(ns.KnotsV))
    else:
        if isinstance(rgCrv, rg.BrepEdge):
            rgE = rgCrv
            rgCrv = rgCrv.EdgeCurve
        else:
            rgE = None
        if not isinstance(rgCrv, rg.NurbsCurve):
            print "{} is a {}.".format(
                "Edge's curve" if rgE else "Curve",
                rgCrv.GetType().Name)
            return
        #knots = rg.NurbsCurve.Knots
        knots = rgCrv.Knots
        print getKnotInfo(knots)


if __name__ == '__main__': main()