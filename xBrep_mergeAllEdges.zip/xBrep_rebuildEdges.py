"""
160713-14: Created.
...
191215: Modified an option default.
200202: Refactored Opts and getInput.  Removed an option.
200204-05: Added bRebuildOnlyOutOfTol and routines to more selectively rebuild edges.
200213: Bug fix.
200507: Improved handling of breps with edges with error in value of Tolerance.
200625: Disabled use of Brep.Standardize due to problems with short edges.
201211: Added check to maximum allowed tolerance before increasing working tolerance.

TODO: Investigate problem with brep as demonstrated by use of Brep.Standardize.
"""

import Rhino
import Rhino.DocObjects as rd
import Rhino.Geometry as rg
import Rhino.Input as ri
import rhinoscriptsyntax as rs
import scriptcontext as sc

from System import Guid


class Opts:

    keys = []
    values = {}
    names = {}
    riOpts = {}
    riAddOpts = {}
    stickyKeys = {}


    def addOptionDouble(key, names, riOpts):
        return lambda getObj: ri.Custom.GetBaseClass.AddOptionDouble(
            getObj, englishName=names[key], numberValue=riOpts[key])


    def addOptionInteger(key, names, riOpts):
        return lambda getObj: ri.Custom.GetBaseClass.AddOptionInteger(
            getObj, englishName=names[key], intValue=riOpts[key])


    def addOptionList(key, names, listValues, values):
        return lambda getObj: ri.Custom.GetBaseClass.AddOptionList(
            getObj,
            englishOptionName=names[key],
            listValues=listValues,
            listCurrentIndex=values[key])


    def addOptionToggle(key, names, riOpts):
        return lambda getObj: ri.Custom.GetBaseClass.AddOptionToggle(
            getObj, englishName=names[key], toggleValue=riOpts[key])


    key = 'fTol'; keys.append(key)
    values[key] = 1.0 * sc.doc.ModelAbsoluteTolerance
    names[key] = 'Tolerance'
    riOpts[key] = ri.Custom.OptionDouble(initialValue=values[key])
    riAddOpts[key] = addOptionDouble(key, names, riOpts)
    stickyKeys[key] = '{}({})({})'.format(key, __file__, sc.doc.Name)

    key = 'bRebuildOnlyOutOfTol'; keys.append(key)
    values[key] = True
    names[key] = key[1:]
    riOpts[key] = ri.Custom.OptionToggle(initialValue=values[key], offValue='No', onValue='Yes')
    riAddOpts[key] = addOptionToggle(key, names, riOpts)
    stickyKeys[key] = '{}({})'.format(key, __file__)

    key = 'bRebuildSharedEdges'; keys.append(key)
    values[key] = True
    names[key] = key[1:]
    riOpts[key] = ri.Custom.OptionToggle(initialValue=values[key], offValue='No', onValue='Yes')
    riAddOpts[key] = addOptionToggle(key, names, riOpts)
    stickyKeys[key] = '{}({})'.format(key, __file__)

    key = 'bRebuildVertices'; keys.append(key)
    values[key] = True
    names[key] = key[1:]
    riOpts[key] = ri.Custom.OptionToggle(initialValue=values[key], offValue='No', onValue='Yes')
    riAddOpts[key] = addOptionToggle(key, names, riOpts)
    stickyKeys[key] = '{}({})'.format(key, __file__)

    key = 'bReplace'; keys.append(key)
    values[key] = True
    names[key] = 'Action'
    riOpts[key] = ri.Custom.OptionToggle(initialValue=values[key], offValue='Add', onValue='Replace')
    riAddOpts[key] = addOptionToggle(key, names, riOpts)
    stickyKeys[key] = '{}({})'.format(key, __file__)

    key = 'bAddDot'; keys.append(key)
    values[key] = False
    names[key] = key[1:]
    riOpts[key] = ri.Custom.OptionToggle(values[key], 'No', 'Yes')
    riAddOpts[key] = addOptionToggle(key, names, riOpts)
    stickyKeys[key] = '{}({})'.format(key, __file__)

    key = 'iDotHeight'; keys.append(key)
    values[key] = 11
    names[key] = key[1:]
    riOpts[key] = ri.Custom.OptionInteger(values[key], setLowerLimit=True, limit=3)
    riAddOpts[key] = addOptionInteger(key, names, riOpts)
    stickyKeys[key] = '{}({})'.format(key, __file__)

    key = 'bEcho'; keys.append(key)
    values[key] = True
    names[key] = key[1:]
    riOpts[key] = ri.Custom.OptionToggle(initialValue=values[key], offValue='No', onValue='Yes')
    riAddOpts[key] = addOptionToggle(key, names, riOpts)
    stickyKeys[key] = '{}({})'.format(key, __file__)

    key = 'bDebug'; keys.append(key)
    values[key] = False
    names[key] = key[1:]
    riOpts[key] = ri.Custom.OptionToggle(initialValue=values[key], offValue='No', onValue='Yes')
    riAddOpts[key] = addOptionToggle(key, names, riOpts)
    stickyKeys[key] = '{}({})'.format(key, __file__)

    # Load sticky.
    for key in stickyKeys:
        if stickyKeys[key] in sc.sticky:
            if key in riOpts:
                riOpts[key].CurrentValue = values[key] = sc.sticky[stickyKeys[key]]
            else:
                values[key] = sc.sticky[stickyKeys[key]]


    @classmethod
    def setValues(cls):
        for key in cls.keys:
            if key in cls.riOpts:
                cls.values[key] = cls.riOpts[key].CurrentValue


    @classmethod
    def saveSticky(cls):
        for key in cls.stickyKeys:
            if key in cls.riOpts:
                sc.sticky[cls.stickyKeys[key]] = cls.riOpts[key].CurrentValue
            else:
                sc.sticky[cls.stickyKeys[key]] = cls.values[key]


def getInput():
    """
    Get breps and options values.
    """

    go = ri.Custom.GetObject()

    go.SetCommandPrompt("Select breps")

    go.GeometryFilter = rd.ObjectType.Brep
    #go.GeometryAttributeFilter = ri.Custom.GeometryAttributeFilter.OpenSurface

    go.AlreadySelectedObjectSelect = True
    go.DeselectAllBeforePostSelect = False
    go.SubObjectSelect = False

    go.EnableClearObjectsOnEntry(False)
    #go.EnableUnselectObjectsOnExit(False)

    go.AcceptNumber(enable=True, acceptZero=True)

    idxs_Opts = {}

    while True:
        key = 'fTol'; idxs_Opts[key] = Opts.riAddOpts[key](go)
        key = 'bRebuildOnlyOutOfTol'; idxs_Opts[key] = Opts.riAddOpts[key](go)
        key = 'bRebuildSharedEdges'; idxs_Opts[key] = Opts.riAddOpts[key](go)
        key = 'bRebuildVertices'; idxs_Opts[key] = Opts.riAddOpts[key](go)
        key = 'bReplace'; idxs_Opts[key] = Opts.riAddOpts[key](go)
        key = 'bAddDot'; idxs_Opts[key] = Opts.riAddOpts[key](go)
        key = 'iDotHeight'; idxs_Opts[key] = (Opts.riAddOpts[key](go)
                                              if Opts.values['bAddDot']
                                              else None)
        key = 'bEcho'; idxs_Opts[key] = Opts.riAddOpts[key](go)
        key = 'bDebug'; idxs_Opts[key] = Opts.riAddOpts[key](go)


        res = go.GetMultiple(minimumNumber=1, maximumNumber=0)

        if res == ri.GetResult.Cancel:
            go.Dispose()
            return
        elif res == ri.GetResult.Object:
            objrefs = go.Objects()
            go.Dispose()
            return tuple([objrefs] + [Opts.values[key] for key in Opts.keys])
        else:
            # An option was selected or a number was entered.
            key = 'fTol'
            if res == ri.GetResult.Number:
                Opts.riOpts[key].CurrentValue = go.Number()
            if Opts.riOpts[key].CurrentValue < 0.0:
                Opts.riOpts[key].CurrentValue = Opts.riOpts[key].InitialValue

            Opts.setValues()
            Opts.saveSticky()
            go.ClearCommandOptions()


def processBrep(rgBrep, **kwargs):
    """
    Parameters:
        rgBrep
        fTol
        bRebuildOnlyOutOfTol
        bRebuildSharedEdges
        bRebuildVertices
        bAddDot
        iDotHeight
        bEcho
        bDebug

    Returns:
        rgBrep, None
        or
        None, str(Explanation of why there is no returned brep)
    """


    def getOpt(key): return kwargs[key] if key in kwargs else Opts.values[key]

    fTol = getOpt('fTol')
    bRebuildOnlyOutOfTol = getOpt('bRebuildOnlyOutOfTol')
    bRebuildSharedEdges = getOpt('bRebuildSharedEdges')
    bRebuildVertices = getOpt('bRebuildVertices')
    bAddDot = getOpt('bAddDot')
    iDotHeight = getOpt('iDotHeight')
    bEcho = getOpt('bEcho')
    bDebug = getOpt('bDebug')



    def dotCurveMidpoint(rgCrv, text='', rgb=(255, 255, 255)):
        pt = rgCrv.PointAtNormalizedLength(0.5)
        if pt.X == Rhino.RhinoMath.UnsetValue:
            pt = rgCrv.PointAtStart
        rs.ObjectColor(rs.AddTextDot(text, pt), rgb)


    def faceEdgesControlPointCounts(rgFace, bDebug=None):
        """
        Returns: List of control point counts of each edge of face.
        """
    
        if bDebug is None: bDebug=Opts.values['bDebug']
    
        rgBrep = rgFace.Loops[0].Brep
    
        iCt_Cp_Face_PreRebuild = []
        for i, iE in enumerate(rgFace.AdjacentEdges()):
            rgEdge = rgBrep.Edges[iE]
            #dotCurveMidpoint(rgEdge, str(i))
            rgNurbsCrv = rgEdge.ToNurbsCurve()
            if rgNurbsCrv is None:
                if bDebug: sEval = 'rgNurbsCrv'; print sEval+':', eval(sEval)
                continue
            numPts = rgNurbsCrv.Points.Count
            rgNurbsCrv.Dispose()
            iCt_Cp_Face_PreRebuild.append(numPts)
        return iCt_Cp_Face_PreRebuild


    def formatDistance(fDistance):
        if fDistance is None:
            return "(None)"
        if fDistance == Rhino.RhinoMath.UnsetValue:
            return "(Infinite)"
        if fDistance < 10.0**(-(sc.doc.DistanceDisplayPrecision-1)):
            return "{:.2e}".format(fDistance)
        return "{:.{}f}".format(fDistance, sc.doc.ModelDistanceDisplayPrecision)


    def computeMaxEdgeDev(rgFace):
        rgB_1F_NotRebuilt = rgFace.DuplicateFace(False)
        rgB_1F_Rebuilt = rgB_1F_NotRebuilt.DuplicateBrep()
        rgB_1F_Rebuilt.Faces[0].RebuildEdges(
            tolerance=0.1*fTol_AbsMax,
            rebuildSharedEdges=True,
            rebuildVertices=bRebuildVertices)

        deviations = []

        for iE in rgB_1F_NotRebuilt.Faces[0].AdjacentEdges():
            rc = rg.Curve.GetDistancesBetweenCurves(
                rgB_1F_NotRebuilt.Edges[iE],
                rgB_1F_Rebuilt.Edges[iE],
                tolerance=0.01*fTol_AbsMax)
            if not rc[0]:
                s = "An EdgeCurve deviation could not be obtained."
                if bEcho: print s
                return
            else:
                deviations.append(rc[1])

        rgB_1F_NotRebuilt.Dispose()
        rgB_1F_Rebuilt.Dispose()

        return max(deviations)


    def determineFacesToRebuild():
        """
        """

        fTol_WIP = sc.doc.ModelAbsoluteTolerance

        idx_Fs_WithOutOfTolEs = [] # Core faces to be rebuilt.
        for iF, tol in enumerate(fEdgeDevs_perFace):
            if tol > fTol_AbsMax:
                idx_Fs_WithOutOfTolEs.append(iF)

        idx_Fs_Adj = []
        for iF in idx_Fs_WithOutOfTolEs:
            idx_Fs_Adj.extend(rgB_In.Faces[iF].AdjacentFaces())
        idx_Fs_Adj = sorted(set(idx_Fs_Adj))

        idx_Fs_toCheck = sorted(set(idx_Fs_WithOutOfTolEs + idx_Fs_Adj))

        if bDebug:
            sEval ='idx_Fs_WithOutOfTolEs'; print sEval+':',eval(sEval)
            sEval ='idx_Fs_Adj'; print sEval+':',eval(sEval)
            sEval ='idx_Fs_toCheck'; print sEval+':',eval(sEval)


        rgBs_1F_RebuiltRebuilt = []
        for iF in idx_Fs_toCheck:
            rgB_1F_RebuiltRebuilt = rgB_In.Faces[iF].DuplicateFace(False)
            rgB_1F_RebuiltRebuilt.Faces[0].RebuildEdges(
                tolerance=0.1*fTol_AbsMax,
                rebuildSharedEdges=False,
                rebuildVertices=bRebuildVertices)
            rgBs_1F_RebuiltRebuilt.append(rgB_1F_RebuiltRebuilt)


        while True:
            sc.escape_test()
            idx_Fs_OutOfTol = []

            rgB_Rebuilt = rgB_In.DuplicateBrep() # Always rebuild a fresh brep.

            if bDebug: print "Rebuilding edges ..."

            # Only rebuild core faces.
            # If non-core, adjacent faces are also rebuilt,
            # then results would be per the latter face of each pair processed.
            for iF in idx_Fs_WithOutOfTolEs:
                rgB_Rebuilt.Faces[iF].RebuildEdges(
                    tolerance=fTol_WIP,
                    rebuildSharedEdges=True,
                    rebuildVertices=bRebuildVertices)

            # Check deviations after all edges have been rebuilt.
            for i, iF in enumerate(idx_Fs_toCheck):
                rgB_1F_Rebuilt = rgB_Rebuilt.Faces[iF].DuplicateFace(False)
                rgB_1F_RebuiltRebuilt = rgBs_1F_RebuiltRebuilt[i]

                for iE in range(rgB_1F_Rebuilt.Edges.Count):
                    rc = rg.Curve.GetDistancesBetweenCurves(
                        rgB_1F_Rebuilt.Edges[iE],
                        rgB_1F_RebuiltRebuilt.Edges[iE],
                        tolerance=0.1*fTol_AbsMax)
                    if not rc[0]:
                        s = "F[{}]'s EdgeCurve deviation could not be calculated.".format(iF)
                        s += "  Assuming edge has changed."
                        if bEcho: print s
                        idx_Fs_OutOfTol.append(iF)
                        break # to next face.
                    elif rc[1] > fTol_WIP:
                        deviation = rc[1]
                        idx_Fs_OutOfTol.append(iF)
                        if bDebug:
                            sEval ='iF'; print sEval+':',eval(sEval)
                            sEval ='iE'; print sEval+':',eval(sEval)
                            sEval ='deviation'; print sEval+':',eval(sEval)
                        break # to next face.

            rgB_Rebuilt.Dispose()

            if bDebug: sEval ='idx_Fs_OutOfTol'; print sEval+':',eval(sEval)

            #return idx_Fs_toCheck, fTol_WIP

            if not idx_Fs_OutOfTol:
                return idx_Fs_toCheck, fTol_WIP
            elif fTol_WIP >= fTol_AbsMax:
                return idx_Fs_toCheck, fTol_WIP
            else:
                fTol_WIP_Old = fTol_WIP
                fTol_WIP *= 2.0
                if bDebug:
                    print "Increasing tolerance from {} to {} ...".format(
                        formatDistance(fTol_WIP_Old),
                        formatDistance(fTol_WIP))


    if not rgBrep.IsValid:
        return None, "Invalid brep skipped."


    rgB_In = rgBrep

    fTol_AbsMax = sc.doc.ModelAbsoluteTolerance if fTol is None else fTol
    #fTol_Used = sc.doc.ModelAbsoluteTolerance

    iCt_Cps_In = iCt_Cps_Out = 0
    
    rgB_In.Standardize() # See SDK for best documentation for Standardize.
    rgB_In.Compact()
    
    iCt_Cps_In = iCt_LineCs_Out = iCt_ArcCs_In = iCt_PolyCs_In = iCt_PLCs_In = 0
    iCt_Cps_Out = iCt_LineCs_B1 = iCt_ArcCs_Out = iCt_PolyCs_Out = iCt_PLCs_Out = 0
    
    for e in rgB_In.Edges:
        c = e.EdgeCurve
        if isinstance(c, rg.NurbsCurve):
            iCt_Cps_In += c.Points.Count
        elif isinstance(c, rg.LineCurve):
            iCt_LineCs_Out += 1
        elif isinstance(c, rg.ArcCurve):
            iCt_ArcCs_In += 1
        elif isinstance(c, rg.PolyCurve):
            iCt_PolyCs_In += 1
        elif isinstance(c, rg.PolylineCurve):
            iCt_PLCs_In += 1
        else:
            1/0


    maxDevs_perEdge_Tol_BeforeSetTolBoxesAndFlags = [rgE.Tolerance for rgE in rgB_In.Edges]

    rgB_Out = rgB_In.DuplicateBrep()

    rgB_Out.SetTolerancesBoxesAndFlags(
        bLazy=False,
        bSetVertexTolerances=True,
        bSetEdgeTolerances=True,
        bSetTrimTolerances=True,
        bSetTrimIsoFlags=True,
        bSetTrimTypeFlags=True,
        bSetLoopTypeFlags=True,
        bSetTrimBoxes=True)

    maxDevs_perEdge_Tol_AfterSetTolBoxesAndFlags = [rgE.Tolerance for rgE in rgB_Out.Edges]

    maxDiscrepancyOfReportedTol = abs(
        max(maxDevs_perEdge_Tol_BeforeSetTolBoxesAndFlags) -
        max(maxDevs_perEdge_Tol_AfterSetTolBoxesAndFlags))
    
    bReportedTolCorrected = maxDiscrepancyOfReportedTol > 0.1 * sc.doc.ModelAbsoluteTolerance
    
    if bEcho:
        s  = "Max. of all input brep's BrepEdge.Tolerance"
        s += " Before=>After Brep.SetTolerancesBoxesAndFlags"
        s += ": {}=>{}".format(
            formatDistance(max(maxDevs_perEdge_Tol_BeforeSetTolBoxesAndFlags)),
            formatDistance(max(maxDevs_perEdge_Tol_AfterSetTolBoxesAndFlags)))
        print s

    fEdgeDevs_perFace = [computeMaxEdgeDev(rgF) for rgF in rgB_In.Faces]

    if bEcho:
        print "Actual maximum edge deviation of input brep: {}.".format(
            formatDistance(max(fEdgeDevs_perFace)))


    if not bRebuildOnlyOutOfTol:
        # Will rebuild all.
        idx_Fs_toRE = range(rgB_Out.Faces.Count)
    else:
        if max(fEdgeDevs_perFace) <= fTol_AbsMax:
            idx_Fs_toRE = []
        else:
            rc = determineFacesToRebuild()
            idx_Fs_toRE, fTol_Used = rc
    
            if abs(fTol_Used-fTol_AbsMax) > 1e-9:
                if bEcho:
                    print "Rebuild tolerance of shared edges will be {} instead of {}.".format(
                        formatDistance(fTol_Used),
                        formatDistance(fTol_AbsMax))
            else:
                fTol_Used = fTol_AbsMax

        if not idx_Fs_toRE:
            s = "All curve deviations are within tolerance"
            if bReportedTolCorrected:
                return rgB_Out, s + ", but Edge.Tolerance value(s) were corrected."
            else:
                return None, s + "."

        if bDebug:
            print "Up to {} faces will have their edges rebuilt.".format(len(idx_Fs_toRE))


    idx_Fs_withREs = []

    for iF in idx_Fs_toRE:

        rgFace0 = rgB_In.Faces[iF]
        rgFace1 = rgB_Out.Faces[iF]
        
        if rgB_In.Faces.Count == 1:
            iCt_Cp_Face_PreRebuild = faceEdgesControlPointCounts(rgFace0)
            if not iCt_Cp_Face_PreRebuild :
                sEval = 'iCt_Cp_Face_PreRebuild'
                return None, sEval+':', eval(sEval)
            
            if bEcho:
                print "Control Point Count of Each Edge"
                print "Original: {}".format(iCt_Cp_Face_PreRebuild)
        
        # Rebuild to input tolerance.
        
        # TODO: Determine this:
        # Should a seam be considered a naked edge?
        # Currently, it is not
        
        
        
        if (
            bRebuildOnlyOutOfTol and
            None not in fEdgeDevs_perFace and
            fEdgeDevs_perFace[iF] <= fTol_AbsMax
        ):
            # Do not rebuild.
            continue # to next face.


        # Rebuild.
        bFaceHasSomeNakedEdges = any(rgB_Out.Edges[iE].Valence == rg.EdgeAdjacency.Naked for iE in rgFace1.AdjacentEdges())
        bFaceHasAllNakedEdges = all(rgB_Out.Edges[iE].Valence == rg.EdgeAdjacency.Naked for iE in rgFace1.AdjacentEdges())
        bFaceHasSomeInteriorEdges = any(rgB_Out.Edges[iE].Valence == rg.EdgeAdjacency.Interior for iE in rgFace1.AdjacentEdges())
        bFaceHasAllInteriorEdges = all(rgB_Out.Edges[iE].Valence == rg.EdgeAdjacency.Interior for iE in rgFace1.AdjacentEdges())
        
        if bFaceHasAllNakedEdges:
            # Using fTol_AbsMax.
            if rgFace1.RebuildEdges(
                tolerance=fTol_AbsMax,
                rebuildSharedEdges=False,
                rebuildVertices=bRebuildVertices
            ):
                idx_Fs_withREs.append(iF)
        else:
            # Face has some non-naked edges.
            if bRebuildSharedEdges:
                if rgFace1.RebuildEdges(
                    tolerance=fTol_Used,
                    rebuildSharedEdges=True,
                    rebuildVertices=bRebuildVertices
                ):
                    idx_Fs_withREs.append(iF)
            
            # if bRebuildSharedEdges, this will be the 2nd Rebuild,
            # but will only redo the naked edges.
            if bFaceHasSomeNakedEdges:
                if rgFace1.RebuildEdges(
                    tolerance=fTol_AbsMax,
                    rebuildSharedEdges=False,
                    rebuildVertices=bRebuildVertices
                ):
                    if iF not in idx_Fs_withREs: idx_Fs_withREs.append(iF)

        rgB_Out.Compact()
        # TODO: Standardize can modify the brep edges if any are too short.
        #  Investigate if and how Standardize can be used.  It is now disabled.
        #rgB_Out.Standardize() # See SDK for best documentation for Standardize.
        #rgB_Out.Compact()
        #sc.doc.Objects.AddBrep(rgB_Out); sc.doc.Views.Redraw(); 1/0

        if rgB_In.Faces.Count == 1:
            # Record new control point counts and dot old and new.
            iCt_Cp_Face_PostRebuild = faceEdgesControlPointCounts(rgFace1)
            if iCt_Cp_Face_PostRebuild is None:
                sEval = 'iCt_Cp_Face_PostRebuild'
                return None, sEval+':', eval(sEval)
            
            if bAddDot:
                for i, idxEdge in enumerate(rgFace0.AdjacentEdges()):
                    if iCt_Cp_Face_PreRebuild[i] != iCt_Cp_Face_PostRebuild[i]:
                        s = "{}: {} -> {}".format(
                                idxEdge, iCt_Cp_Face_PreRebuild[i], iCt_Cp_Face_PostRebuild[i])
                        dotCurveMidpoint(rgB_In.Edges[idxEdge], s)
            
            if bEcho:
                print "Rebuilt:  {}".format(iCt_Cp_Face_PostRebuild)


    if bDebug:
        print "{} faces had their edges rebuilt.".format(len(set(idx_Fs_withREs)))


    for e in rgB_Out.Edges:
        c = e.EdgeCurve
        if isinstance(c, rg.NurbsCurve):
            iCt_Cps_Out += c.Points.Count
        elif isinstance(c, rg.LineCurve):
            iCt_LineCs_B1 += 1
        elif isinstance(c, rg.ArcCurve):
            iCt_ArcCs_Out += 1
        elif isinstance(c, rg.PolyCurve):
            iCt_PolyCs_Out += 1
        elif isinstance(c, rg.PolylineCurve):
            iCt_PLCs_Out += 1
        else:
            1/0

    ct_delta_Cp = iCt_Cps_Out - iCt_Cps_In

    bChangeInCrvTypeCts = (
            iCt_LineCs_B1 != iCt_LineCs_Out
            or
            iCt_ArcCs_Out != iCt_ArcCs_In
            or
            iCt_PolyCs_Out != iCt_PolyCs_In
            or 
            iCt_PLCs_Out != iCt_PLCs_In
    )

    bChangeInNCPtCts = iCt_Cps_Out != iCt_Cps_In

    if not (bChangeInCrvTypeCts or bChangeInNCPtCts):
        s  = "No change in curve type counts or NurbsCurve point counts."
        
        for iE in xrange(rgB_In.Edges.Count):
            c0 = rgB_In.Edges[iE].EdgeCurve
            c1 = rgB_Out.Edges[iE].EdgeCurve
            rc = rg.Curve.GetDistancesBetweenCurves(c0, c1, tolerance=0.1*fTol_Used)
            if not rc[0]:
                s += "  EdgeCurve deviation could not be obtained."
                s += "  Assuming edge has changed."
                if bEcho: print s
                break
            if rc[1] >= fTol_Used:
                tA = rc[2]
                ptA_FromGDBC = c0.PointAt(tA)
                tB = rc[3]
                ptB_FromGDBC = c1.PointAt(tB)
                rc = c0.ClosestPoint(ptB_FromGDBC)
                if rc[0]:
                    ptA_ClosestToOnB = c0.PointAt(rc[1])
                rc = c1.ClosestPoint(ptA_FromGDBC)
                if rc[0]:
                    ptB_ClosestToOnA = c1.PointAt(rc[1])
                if (
                        ptA_FromGDBC.DistanceTo(ptB_ClosestToOnA) >= fTol_Used
                        or
                        ptB_FromGDBC.DistanceTo(ptA_ClosestToOnB) >= fTol_Used
                ):
                    if rc[1] < 0.001:
                        s += "  But EdgeCurve deviation of {:.2e} found.".format(rc[1])
                    else:
                        s += "  But EdgeCurve deviation of {:.4f} found.".format(rc[1])
                    if bEcho: print s
                    break
                if bDebug: print "Bad maxDistance from GetDistancesBetweenCurves."
        else:
            if None not in fEdgeDevs_perFace:
                rgB_Out.Dispose()
                return None, s + "  All curve deviations are within tolerance."

    if bEcho:
        s  = "Total edge control point count change:"
        s +=  " {}{} ({} -> {}).".format(
            '+' if ct_delta_Cp > 0 else '',
            ct_delta_Cp,
            iCt_Cps_In,
            iCt_Cps_Out)
        print s

        fEdgeDevs_perFace = [computeMaxEdgeDev(rgF) for rgF in rgB_Out.Faces]

        print "Actual maximum edge tolerance of resultant brep: {}.".format(
            formatDistance(max(fEdgeDevs_perFace)))

    if bDebug:
        print iCt_Cps_In, iCt_LineCs_Out, iCt_ArcCs_In
        print iCt_Cps_Out, iCt_LineCs_B1, iCt_ArcCs_Out


    return rgB_Out, None


def processBrepObjects(rhBreps, **kwargs):
    """
    rhBreps: Can be objrefs, GUIDs, 
    """

    def getOpt(key): return kwargs[key] if key in kwargs else Opts.values[key]

    fTol = getOpt('fTol')
    bRebuildOnlyOutOfTol = getOpt('bRebuildOnlyOutOfTol')
    bRebuildSharedEdges = getOpt('bRebuildSharedEdges')
    bRebuildVertices = getOpt('bRebuildVertices')
    bReplace = getOpt('bReplace')
    bAddDot = getOpt('bAddDot')
    iDotHeight = getOpt('iDotHeight')
    bEcho = getOpt('bEcho')
    bDebug = getOpt('bDebug')


    def getBrep(rhObj):
        if isinstance(rhObj, rg.Brep):
            return None, rhObj
        elif isinstance(rhObj, rg.GeometryBase):
            rdObj = None
            rgObj = rhObj
        elif isinstance(rhObj, rd.ObjRef):
            #print rhObj.GeometryComponentIndex.ComponentIndexType
            rdObj = rhObj.Object()
            rgObj = rhObj.Geometry()
        elif isinstance(rhObj, Guid):
            rdObj = sc.doc.Objects.FindId(rhObj) if Rhino.RhinoApp.ExeVersion >= 6 else sc.doc.Objects.Find(rhObj)
            rgObj = rdObj.Geometry
        else:
            return

        if isinstance(rgObj, rg.Brep):
            return rdObj, rgObj



    rgBreps1 = []
    sLogs = []
    gBreps1 = []
    
    for rhBrep0 in rhBreps:

        rc = getBrep(rhBrep0)
        if not rc:
            raise ValueError(
                "{} passed to processBrepObjects." \
                    "  Only ObjRef, DocObject, Geometry, or an iterable combination" \
                    " are accepted input.")

        rdBrep0, rgB0 = rc

        rc = processBrep(
                rgBrep=rgB0,
                fTol=fTol,
                bRebuildOnlyOutOfTol=bRebuildOnlyOutOfTol,
                bRebuildSharedEdges=bRebuildSharedEdges,
                bRebuildVertices=bRebuildVertices,
                bAddDot=bAddDot,
                iDotHeight=iDotHeight,
                bEcho=bEcho if len(rhBreps) == 1 else False,
                bDebug=bDebug
        )
        if not rc[0]:
            sLogs.append(rc[1])
        else:
            rgB_Out = rc[0]
            sLogs.append(rc[1])
            rgBreps1.append(rgB_Out)
            if bReplace:
                bSuccess = sc.doc.Objects.Replace(rdBrep0.Id, rgB_Out)
                if bSuccess: gBreps1.append(rdBrep0.Id)
            else:
                gBrep1 = sc.doc.Objects.AddBrep(rgB_Out)
                bSuccess = gBrep1 != Guid.Empty
                if bSuccess: gBreps1.append(gBrep1)
        rgB0.Dispose()
    
    for b in rgBreps1: b.Dispose()
    
    iBreps0_ct = len(rhBreps)

    if bEcho:
        if len(rhBreps) == 1:
            s = ""
            if sLogs and sLogs[0]:
                s += sLogs[0]
                s += "  "
            if bReplace:
                if gBreps1:
                    s += "Brep was modified.".format(
                            len(gBreps1), iBreps0_ct)
                else:
                    s +=  "Brep was not modified."
            else:
                if gBreps1:
                    s += "Brep has been added.".format(
                            len(gBreps1), iBreps0_ct)
                else:
                    s += "Brep was not added."
            print s
        elif len(rhBreps) > 1:
            for sFail in set(sLogs):
                print "[{}] {}".format(sLogs.count(sFail), sFail)
            if bReplace:
                if gBreps1:
                    print "{} of {} brep(s) have been modified.".format(
                            len(gBreps1), iBreps0_ct)
                else:
                    print "No breps have been modified."
            else:
                if gBreps1:
                    print "{} of {} brep(s) have been added.".format(
                            len(gBreps1), iBreps0_ct)
                else:
                    print "No breps have been added."
    
    return gBreps1


def main():
    
    rc = getInput()
    if rc is None: return

    objrefs = rc[0]
    bDebug = Opts.values['bDebug']

    if bDebug:
        pass
    else:
        sc.doc.Views.RedrawEnabled = False

    Rhino.RhinoApp.SetCommandPrompt("Working ...")

    rc = processBrepObjects(rhBreps=objrefs)

    sc.doc.Views.RedrawEnabled = True


if __name__ == '__main__': main()