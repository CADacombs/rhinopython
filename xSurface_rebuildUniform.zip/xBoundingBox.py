"""
...
190505: Removed a function.
200525-26: Added functionality so this script can be run on its own or continued being used as a module.

TODO:
    Merge BoundingBox2 with this script.  It includes options for center point, etc.
"""

import Rhino
import Rhino.DocObjects as rd
import Rhino.Geometry as rg
import Rhino.Input as ri
import scriptcontext as sc

from System import Guid


def createBoundingBox(rgObjs):
    try: rgObjs = list(rgObjs)
    except: rgObjs = [rgObjs]
    bbox = rg.BoundingBox.Empty
    for geom in rgObjs: bbox.Union(geom.GetBoundingBox(True))
    if bbox is None: raise ValueError("Bounding box not created.")
    return bbox


def epsilonEquals(bBoxA, bBoxB, fTol=sc.doc.ModelAbsoluteTolerance):
    """
    Created because BoundingBox structure does not contain an EpsilonEquals method.
    """
    boxA = Rhino.Geometry.Box(bBoxA)
    if not boxA: return
    boxB = Rhino.Geometry.Box(bBoxB)
    if not boxB: return
    return boxA.EpsilonEquals(boxB, fTol)


def findMatchingBoundingBox(bboxes_toSearch, bbox_toMatch, fTolerance=None, bDebug=False):
    """
    Parameters:
        bboxes_toSearch: Iterable of BoundingBoxes from which to search.
        bbox_toMatch: BoundingBox to match.
        fTolerance
        bDebug
    Return on success:
        int(Index of single matching bounding box)
    Return on fail:
        None
    """

    if bDebug: print 'findMatchingBoundingBox()...'

    if fTolerance is None:
        fTolerance = sc.doc.ModelAbsoluteTolerance

    idx_Found = None

    for i, bbox_toCheck in enumerate(bboxes_toSearch):
        if (
            bbox_toMatch.Min.EpsilonEquals(bboxes_toSearch[i].Min, epsilon=fTolerance) and
            bbox_toMatch.Max.EpsilonEquals(bboxes_toSearch[i].Max, epsilon=fTolerance)
        ):
            if idx_Found is not None:
                print "More than one match found.  Check results."
                return
            idx_Found = i
        
    if idx_Found is None:
        if bDebug:
            print "Matching bounding box NOT found."
            #sc.doc.Objects.AddBrep(bbox_toMatch.ToBrep())
            #for bb in bboxes_toSearch:
                #sc.doc.Objects.AddBrep(bb.ToBrep())

    return idx_Found


def main():
    
    res, objrefs = ri.RhinoGet.GetMultipleObjects(
        "Select objects to create bounding box",
        acceptNothing=False,
        filter=rd.ObjectType.AnyObject)
    if res == Rhino.Commands.Result.Cancel: return

    sc.doc.Objects.UnselectAll()

    Rhino.RhinoApp.SetCommandPrompt("Working ...")

    rgObjs = [o.Geometry() for o in objrefs]

    bbox = createBoundingBox(rgObjs)

    print bbox.Min, type(bbox.Min)

    iCt_MatchingCoords = 0
    bCoordMatches = [False, False, False]
    if abs(bbox.Min.X - bbox.Max.X) < 1e-9:
        iCt_MatchingCoords += 1
        bCoordMatches[0] = True
    if abs(bbox.Min.Y - bbox.Max.Y) < 1e-9:
        iCt_MatchingCoords += 1
        bCoordMatches[1] = True
    if abs(bbox.Min.Z - bbox.Max.Z) < 1e-9:
        iCt_MatchingCoords += 1
        bCoordMatches[2] = True

    iCt_MatchingCoords = bCoordMatches.count(True)

    print bbox

    if iCt_MatchingCoords == 0:
        gBox = sc.doc.Objects.AddBox(rg.Box(bbox=bbox))
        if gBox == Guid.Empty:
            print "Box could not be added."
        else:
            print "Box (extrusion) was added."
            sc.doc.Views.Redraw()
    elif iCt_MatchingCoords == 1:
        print "Bounding box is planar."
        if bCoordMatches[0]:
            plane = rg.Plane.WorldYZ
            plane.Translate(rg.Vector3d(bbox.Min.X, 0.0, 0.0))
        elif bCoordMatches[1]:
            plane = rg.Plane.WorldZX
            plane.Translate(rg.Vector3d(0.0, bbox.Min.Y, 0.0))
        elif bCoordMatches[2]:
            plane = rg.Plane.WorldXY
            plane.Translate(rg.Vector3d(0.0, 0.0, bbox.Min.Z))
        rect = rg.Rectangle3d(
            plane=plane,
            cornerA=bbox.Min,
            cornerB=bbox.Max)
        gPLCrv = sc.doc.Objects.AddRectangle(rect)
        if gPLCrv == Guid.Empty:
            print "Polyline could not be added."
        else:
            sc.doc.Views.Redraw()
            print "Polyline was added."
    elif iCt_MatchingCoords == 2:
        print "Bounding box is linear."
        gLineCrv = sc.doc.Objects.AddLine(bbox.Min, to=bbox.Max)
        if gLineCrv == Guid.Empty:
            print "Line could not be added."
        else:
            sc.doc.Views.Redraw()
            print "Line was added."
    elif iCt_MatchingCoords == 3:
        print "Bounding box is a point.  Point was not added."


if __name__ == '__main__': main()