"""
160531-0602: Created by importing functions from other scripts.
160607: Addition.
160609: Mod.
160611: Major additions for removeTrim.
160612: Bug fix in addOuterLoop.
160623: Added retrimOneFaceBrep() and trimOneFaceBrepWithCurves().
160706: Moved a couple functions to another module.
160725: Added ptOnFaceMinDistFromBorder().
160819: Added indicesOfInvalidBrepFaces().
160824: Fixed bug in orderedLists_AdjFLT_perSelFBorders and renamed to orderedLists_AdjacentFLT_perSelFBorders.
160826: trimOneFaceBrepWithCurves(): Default value of bShrinkFaces changed from True to False.
160829: removeTrim: Fixed initializing list bug.
        Renamed ptOnFaceMinDistFromBorder() to ptOnFaceNotOnBorder and added default value for fDistMin.
160831: Moved addOuterLoop, indicesOfTrimsNotToRemove, removeTrim to untrimLocal.py
160901: Updated debugging.
160902: tryExistingEdgeMatchingCurvx: Replaced length comparison with curve deviation check.
160911: Moved orderedLists_AdjacentFLT_perSelFBorders to another script.
170630: ptOnFaceNotOnBorder: Now skips faces whose AreaMassProperties.Compute's output is None.
181020: Removed indicesOfInvalidBrepFaces.
181029: addSenwEdgeTrimToLooX: Added code with intrvl.Swap() to avoid
190413: Removed some functions.
190505: Some functions moved to other scripts.
190506: Added some functions.
190522: Import-related update.
190523-24: Added some functions.
190617: Fixed minor bug.
190720: Edits to assist debugging.
190731: Import-related update.
190810: Added fTolerance to some functions.  Adddd curve and brep cleaning.
190822: Import-related update.
190829: Removed an unused function.
191004: Transferred 2 functions to other scripts.
191118: Moved 2 functions to another module.
191121: Import-related update.
200107: Modified this history log.
200401: Removed functions that were already in another script.  Modified this history log.

TODO:
    Rotate RevSurface's before moving seams to avoid conversion to NurbsSurface.
"""

import Rhino
import Rhino.DocObjects as rd
import Rhino.Geometry as rg
import scriptcontext as sc

from System import Guid

import random

import xBoundingBox


maxExponentFor2 = 4


def coerceBrep(rhBrep0):
    """
    Replacement for rhinoscriptsyntax's coercebrep.
    """
    
    # First test for Rhino.Geometry, then GUID, then ObjRef, then Rhino.DocObject
    if isinstance(rhBrep0, rg.Brep):
        return rhBrep0.DuplicateBrep() # Duplication allows rhBrep0 to be Disposed in calling function.)
    elif isinstance(rhBrep0, Guid):
        rdBrep = sc.doc.Objects.FindId(rhBrep0) if Rhino.RhinoApp.ExeVersion >= 6 else sc.doc.Objects.Find(rhBrep0)
        return rdBrep.Geometry
    elif isinstance(rhBrep0, rd.ObjRef):
        objref = rhBrep0
        if objref.GeometryComponentIndex.Index == -1:
            return objref.Geometry()
        elif (
                objref.GeometryComponentIndex.ComponentIndexType ==
                rg.ComponentIndexType.BrepFace
        ):
            return objref.Geometry().\
                    Faces[objref.GeometryComponentIndex.Index].\
                            DuplicateFace(False)
    elif isinstance(rhBrep0, rd.BrepObject):
        return rhBrep0.Geometry
    elif isinstance(rhBrep0, rg.BrepFace):
        return rhBrep0.DuplicateFace(False)
    elif isinstance(rhBrep0, rg.Surface):
        return rhBrep0.ToBrep()


def doesLoopHaveMultipleTrimsOnAnyNaturalEdges(rgLoop):
    W = sum(1 for rgTrim in rgLoop.Trims if rgTrim.IsoStatus == Rhino.Geometry.IsoStatus.West)
    S = sum(1 for rgTrim in rgLoop.Trims if rgTrim.IsoStatus == Rhino.Geometry.IsoStatus.South)
    E = sum(1 for rgTrim in rgLoop.Trims if rgTrim.IsoStatus == Rhino.Geometry.IsoStatus.East)
    N = sum(1 for rgTrim in rgLoop.Trims if rgTrim.IsoStatus == Rhino.Geometry.IsoStatus.North)
    return (W > 1 or S > 1 or E > 1 or N > 1)


def findMatchingBrepInBrepSplitUsingEdgeBBox(rgBrep_Split, rgBrep0_1F, bGetNegative=False, bEcho=False):
    if bEcho: print 'findMatchingBrepInBrepSplitUsingEdgeBBox()...'
    
    rgCrvs_B0Edges = rgBrep0_1F.DuplicateEdgeCurves() # Includes seams
    
    rgBbox_B0Crvs = None
    for rgCrv in rgCrvs_B0Edges:
        rgBbox = rgCrv.GetBoundingBox(True)
        rgCrv.Dispose()
        if rgBbox_B0Crvs is None: rgBbox_B0Crvs = rgBbox
        else: rgBbox_B0Crvs.Union(rgBbox)
    
    for e in (0,1):
        fEpsEqTol = sc.doc.ModelAbsoluteTolerance * 10.**e
        if bGetNegative: rgBreps_Negs = []
        
        for rgFace in rgBrep_Split.Faces:
            rgBrep1_1F = rgFace.DuplicateFace(False)
            rgFace.Dispose()
            if rgBrep1_1F is None:
                if bEcho: sPrint = 'rgBrep1_1F'; print sPrint + ':', eval(sPrint)
                return
            
            rgCrvs_B1Edges = rgBrep1_1F.DuplicateEdgeCurves()
            
            """ Test one bounding box for each complete set of edges of each face
            against the bounding box of the splitting curves."""
            bBox_SplitEs = None
            for rgCrv in rgCrvs_B1Edges:
                rgBbox = rgCrv.GetBoundingBox(True)
                rgCrv.Dispose()
                if bBox_SplitEs is None: bBox_SplitEs = rgBbox
                else: bBox_SplitEs.Union(rgBbox)
            
            if xBoundingBox.epsilonEquals(rgBbox_B0Crvs, bBox_SplitEs, fEpsEqTol): # From geometry.py.
                if not bGetNegative: return rgBrep1_1F
            else:
                if bGetNegative: rgBreps_Negs.append(rgBrep1_1F)
            
            if not bGetNegative: rgBrep1_1F.Dispose()
        
        if bGetNegative and (len(rgBreps_Negs) == rgBrep_Split.Faces.Count-1):
            return rgBreps_Negs


def findMatchingBrepInBrepSplitUsingFaceBBox(rgBrep_Split, rgBrep0_1F, bGetNegative=False, bEcho=False):
    if bEcho: print 'findMatchingBrepInBrepSplitUsingFaceBBox()...'
    
    rgBbox_B0 = rgBrep0_1F.GetBoundingBox(True)
    
    for e in (0,1):
        fEpsEqTol = sc.doc.ModelAbsoluteTolerance * 10.**e
        if bGetNegative: rgBreps_Negs = []
        
        # Test one bounding box of each face against bounding box of original brep.
        for rgFace in rgBrep_Split.Faces:
            rgBrep1_1F = rgFace.DuplicateFace(False)
            rgFace.Dispose()
            if rgBrep1_1F is None:
                if bEcho: sPrint = 'rgBrep1_1F'; print sPrint + ':', eval(sPrint)
                return
            
            bBox_SplitF = rgBrep1_1F.GetBoundingBox(True)
    #            rgBrepTest = rg.Brep.CreateFromBox(bBox_SplitF)
    #            sc.doc.Objects.AddBrep(rgBrepTest)
    #            sc.doc.Views.Redraw()
            
            if xBoundingBox.epsilonEquals(rgBbox_B0, bBox_SplitF, fEpsEqTol): # From geometry.py.
                if not bGetNegative: return rgBrep1_1F
            else:
                if bGetNegative: rgBreps_Negs.append(rgBrep1_1F)
            
            if not bGetNegative: rgBrep1_1F.Dispose()
        
        if bGetNegative and (len(rgBreps_Negs) == rgBrep_Split.Faces.Count-1):
            return rgBreps_Negs


def indicesOfVerticesWithoutEdges(rgBrep):
    idxV_Es = set()
    for rgE in rgBrep.Edges:
        if rgE.StartVertex.VertexIndex is not None:
            idxV_Es.add(rgE.StartVertex.VertexIndex)
        if rgE.EndVertex.VertexIndex is not None:
            idxV_Es.add(rgE.EndVertex.VertexIndex)
    
    return [idxV for idxV in rgBrep.Vertices if idxV in idxV_Es]


def ptOnFaceNotOnBorder(rgBrep, idxFace, fDistMin=10.*sc.doc.ModelAbsoluteTolerance):
    """
    Parameters:
        rgBrep: Used to get the edges from the edge indices.
        idxFace
        fDistMin: Minimum distance from the face border.
    Returns:
        Point3d on success, None on failure
    """
    
    rgFace = rgBrep.Faces[idxFace]
    
    areaMassProp = Rhino.Geometry.AreaMassProperties.Compute(rgFace)
    if areaMassProp is None:
        print "Face index {} skipped because its AreaMassProperties, " \
        "and thus its centroid, cannot be calculated.".format(
                idxFace)
        return
    
    ptCentrdW = areaMassProp.Centroid
    getrc, u, v = rgFace.ClosestPoint(ptCentrdW)
    domnU, domnV = rgFace.Domain(0), rgFace.Domain(1)
    fIE = 0. # Ratio from surface borders
    
    rgEdges = [rgBrep.Edges[idxEdge] for idxEdge in rgFace.AdjacentEdges()]
    
    for i in xrange(100000): # If point is not on face, continue searching.
        if rgFace.IsPointOnFace(u, v):# If point is not at least fDistMin from border, continue searching.
            pt = rgFace.PointAt(u, v)
            for rgEdge in rgEdges:
                b, t = rgEdge.ClosestPoint(pt)
                if b:
                    if pt.DistanceTo(rgEdge.PointAt(t)) < fDistMin: # Too close
                        break
            else: # Good point
                map(lambda x: x.Dispose(), rgEdges)
                rgFace.Dispose()
                return pt
        
        # Get new parameters for point.
        u = random.uniform(domnU.T0 + fIE*domnU.Length,
                domnU.T1 - fIE*domnU.Length)
        v = random.uniform(domnV.T0 + fIE*domnV.Length,
                domnV.T1 - fIE*domnV.Length)
    
    map(lambda x: x.Dispose(), rgEdges)
    rgFace.Dispose()


def retrimOneFaceBrep(rgBrep, fRebuildTol=None):
    """
    Returns:
        One face trimmed brep.
        None on failure.
    Face.RebuildEdges() of rgBrep0's existing edges will be used for trimming
    curves.
    """
    if rgBrep.IsSurface or rgBrep.Faces.Count != 1: return
    rgFace = rgBrep.Faces[0]
    if fRebuildTol is not None:
        rgFace.RebuildEdges(fRebuildTol, False, True)
    rgEdges = rgBrep.DuplicateNakedEdgeCurves(True, True)
    return trimOneFaceBrepWithCurves(rgFace.ToBrep(), rgEdges)


def rotateRoundBrepToAvoidCurves(rgBrep0, rgCrvs_ToAvoid, rotationAxis, rotationCenter, fTolerance=0.1*sc.doc.ModelAbsoluteTolerance, bDebug=False):
    """
    Parameters:
        rgBrep0
        rgCrvs_ToAvoid
        rotationCenter
    Returns: New brep
    Moves surface (from sphere) seam away from rgCrvs_ToAvoid.
    Do not use this for spherical surfaces."""
        
    # Join curves to be avoided.  Joining them now will reduce the number of tests.
    rgCrvs_ToAvoid_Joined = rg.Curve.JoinCurves(rgCrvs_ToAvoid, fTolerance)
    if rgCrvs_ToAvoid_Joined is None:
        print "JoinCurves of Curves to Avoid failed!"
        return
    for c in rgCrvs_ToAvoid_Joined:
        if not c.IsClosed:
            print "Joined curve of Curves to Avoid is not closed."
            return
    
    rgCrvs_rgBrep0Edges = rgBrep0.Curves3D

    rgCrvs_rgB0Edges_Joined = rg.Curve.JoinCurves(rgCrvs_rgBrep0Edges, fTolerance)
    if rgCrvs_rgB0Edges_Joined is None:
        print "JoinCurves of Surface Border failed!"
        return

    # First test initial orientation.
    def areCurvesTooClose(crvsA, crvsB, distance=4.0*sc.doc.ModelAbsoluteTolerance):
        for cA in crvsA:
            for cB in crvsB:
                rc = cA.ClosestPoints(otherCurve=cB)
                b, ptA, ptB = rc
                if not b:
                    print "ClosestPoints not found!"
                    return
                dist = ptA.DistanceTo(ptB)
                if dist <= distance:
                    return True
        return False
    if not areCurvesTooClose(rgCrvs_ToAvoid_Joined, rgCrvs_rgB0Edges_Joined):
        return rgBrep0
    
    for N in xrange(maxExponentFor2):
        sc.escape_test()
        denominator = 2.0**N
        for numerator in xrange(1, denominator, 2):
            sc.escape_test()
            perunus = float(numerator) / float(denominator)
            angle = Rhino.RhinoMath.ToRadians(360.0)*perunus
            crvs_Rotate = [c.Duplicate() for c in rgCrvs_rgB0Edges_Joined]
            for c in crvs_Rotate:
                c.Rotate(
                        angleRadians=angle,
                        rotationAxis=rotationAxis,
                        rotationCenter=rotationCenter)
                #sc.doc.Objects.AddCurve(c)
            if areCurvesTooClose(rgCrvs_ToAvoid_Joined, crvs_Rotate):
                break # to next axis rotation.
            else:
                # Found good orientation.
                rgBrep_Rotated = rgBrep0.Duplicate()
                if not rgBrep_Rotated.Rotate(
                    angleRadians=angle,
                    rotationAxis=rotationAxis,
                    rotationCenter=rotationCenter
                ):
                    return
                return rgBrep_Rotated


def trimOneFaceBrepWithCurves(rgBrep0, rgCrvs0, bShrinkFaces=False):
    """
    Returns:
        One face trimmed brep.
        None on failure.
    """
    if rgBrep0.Faces.Count != 1: return
    rgFace0 = rgBrep0.Faces[0]
    rgBrep_Split = rgFace0.Split(rgCrvs0, sc.doc.ModelAbsoluteTolerance)
    if not rgBrep_Split: return
    
    rgBbox_rgCrvs0 = None
    for rgCrv in rgCrvs0:
        rgBbox = rgCrv.GetBoundingBox(True)
        if rgBbox_rgCrvs0 is None: rgBbox_rgCrvs0 = rgBbox
        else: rgBbox_rgCrvs0.Union(rgBbox)
    
    for rgFace in rgBrep_Split.Faces:
        idx_rgEdges = rgFace.AdjacentEdges()
        """ Test one bounding box for each complete set of borders of each face
        against bounding box of splitting curves."""
        bBox_SplitEs = None
        for i in idx_rgEdges:
            rgBbox = rgBrep_Split.Edges[i].GetBoundingBox(True)
            if bBox_SplitEs is None: bBox_SplitEs = rgBbox
            else: bBox_SplitEs.Union(rgBbox)
        if xBoundingBox.epsilonEquals(rgBbox_rgCrvs0, bBox_SplitEs,
                10.0*sc.doc.ModelAbsoluteTolerance):
            rgBrep1 = rgFace.DuplicateFace(False)
            if bShrinkFaces:
                rgBrep1.Faces.ShrinkFaces()
            return rgBrep1 # Returns brep.


def test_pickFaceInBlock():
    
    go = Rhino.Input.Custom.GetObject()
    go.SetCommandPrompt("Select face")
    go.GeometryFilter = (Rhino.DocObjects.ObjectType.Surface |
            Rhino.DocObjects.ObjectType.InstanceReference)
    
    go.EnableHighlight(False)
    
    rgFace = None
    
    while rgFace is None:
        sc.escape_test()
        while go.Get() != Rhino.Input.GetResult.Object:
            sc.escape_test()
            if go.CommandResult() != Rhino.Commands.Result.Success: return # No input or Esc key was pressed.
        
        objref = go.Object(0)
        rdObj = objref.Object()
        ptPicked = objref.SelectionPoint()
        
        if go.ObjectsWerePreselected:
            if rdObj.ObjectType == Rhino.DocObjects.ObjectType.Brep:
                rgObj = rdObj.BrepGeometry
            elif rdObj.ObjectType == Rhino.DocObjects.ObjectType.Extrusion:
                rgObj = rdObj.Geometry.ToBrep()
            else:
                sc.doc.Objects.UnselectAll() # Necessary if instance reference was preselected.
                sc.doc.Views.Redraw()
                continue
            if rgObj.Faces.Count == 1: rgFace = rgObj.Faces[0]
        if rdObj.ObjectType == Rhino.DocObjects.ObjectType.InstanceReference:
            rgFace, ptPicked = tryPickedFaceOfBlock(rdObj, ptPicked)
        else: rgFace = objref.Face() # This also works for ExtrusionObject.
        
        #if rgFace is None: sc.doc.Objects.UnselectAll() # Necessary when go.Get() is repeated.
        #sc.doc.Objects.AddSurface(rgFace)
        #print rgFace
        #print ptPicked
        sc.doc.Objects.AddPoint(ptPicked); sc.doc.Views.Redraw()
        rgFace = None
        sc.doc.Objects.UnselectAll()


#if __name__ == '__main__': pickFaceInBlockTester()