"""
190425: Created.
190701: Modified to be used as an import.
190826: Now, Brep is not replaced if all component counts remain the same.
191118: Modified printed output.
"""

import Rhino
import rhinoscriptsyntax as rs
import scriptcontext as sc


def processBrepObjects(gBreps, bEcho=True, bDebug=False):
    """
    """
    
    sComponents = (
            'Trims',
            'Curves2D',
            'Edges',
            'Curves3D',
            'Faces',
            'Surfaces',
            'Loops',
            'Vertices',
    )
    
    gBreps_Replaced = []

    Rhino.RhinoApp.SetCommandPrompt("Searching ...")

    for gBrep in gBreps:
        rgBrep = rs.coercebrep(gBrep)
        if not rgBrep:
            if bEcho: print "Geometry for {} cannot be obtained.".format(gBrep)
            continue
        if not rgBrep.IsValid:
            if bEcho: print "Geometry for {} before Compact is not valid.".format(gBrep)
            rgBrep.Dispose()
            continue
        
        compCounts_Pre = [eval("rgBrep.{}.Count".format(s)) for s in sComponents]
        
        rgBrep.Compact()
        
        compCounts_Post = [eval("rgBrep.{}.Count".format(s)) for s in sComponents]
        
        for i in range(len(compCounts_Pre)):
            if compCounts_Pre[i] != compCounts_Post[i]:
                break
        else:
            if bEcho and len(gBreps) == 1:
                s  = "Brep's component counts before and after Compact are the same."
                s += "  Brep was not modified."
                print s
            rgBrep.Dispose()
            continue
        
        for i in range(len(compCounts_Pre)):
            if compCounts_Pre[i] != compCounts_Post[i]:
                print "{}: {} -> {}".format(
                        sComponents[i], compCounts_Pre[i], compCounts_Post[i])
        
        if not rgBrep.IsValid:
            if bEcho: print "Geometry for {} after Compact is not valid.".format(gBrep)
            rgBrep.Dispose()
            continue
        
        if not sc.doc.Objects.Replace(objectId=gBrep, brep=rgBrep):
            if bEcho: print "Geometry for {} could not be replaced.".format(gBrep)
            rgBrep.Dispose()
            continue
        else: 
            gBreps_Replaced.append(gBrep)
        
        rgBrep.Dispose()
    
    if bEcho: print "{} out of {} breps replaced with geometry modified by Compact.".format(
            len(gBreps_Replaced), len(gBreps))


def main(bEcho=True, bDebug=False):
    
    gBreps = rs.GetObjects("Select breps", filter=rs.filter.polysurface + rs.filter.surface,
            preselect=True, select=False)
    if not gBreps: return
    
    processBrepObjects(gBreps, bEcho=bEcho, bDebug=bEcho)
    
    sc.doc.Views.Redraw()


if __name__ == '__main__': main(bEcho=bool(1), bDebug=bool(0))