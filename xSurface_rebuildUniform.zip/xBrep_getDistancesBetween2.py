"""
171111-23: Created.
171209: Name changed from ...py to ...py
        Added isMaximumWithinTolerance.
181128: Improved output threshold for adding dots and lines.
181202: Changed name from ...py to ...py.
        Moved .. and .. to Brep_.py.
190119-20: Now accepts 2 breps of any face count instead of only polyface ones.
190218: Modified printed output.
190220: Added functions from another module.  Refactored.  Intersection calculation is now skipped if minimum distance is within ModelAbsoluteTolerance.
190304: Updated an import name.
190508: Updated a function's return data on an error.
190510: Moved MeshingParameters creation into one function.
190530: Modified an option default.
190813: Now, double precision is determined by whole numbers of brep's coordinates and fractional decimal places of ModelAbsoluteTolerance.

Accuracy is about 6 decimal places.
Values at indices 2, 3, 5, and 6 are Pt3ds, not parameter values.
"""

import Rhino
import Rhino.DocObjects as rd
import Rhino.Geometry as rg
import Rhino.Input as ri
import rhinoscriptsyntax as rs
import scriptcontext as sc

import math

from System.Diagnostics import Stopwatch

import xBrep


stopwatch = Stopwatch()

iDotDecPlaces_Default = sc.doc.ModelDistanceDisplayPrecision


def getInput():
    """
    """
    
    
    # Load sticky.
    stickyKeys = [
            'bIncludeEdges({})'.format(__file__),
            'bFineMesh({})'.format(__file__),
            'bAddMarks({})'.format(__file__),
            'bAddLine({})'.format(__file__),
            'bAddDot({})'.format(__file__),
            'iDotDecPlaces({})({})'.format(__file__, sc.doc.Name),
            'iDotFontHt({})'.format(__file__),
            'bAddMax({})'.format(__file__),
            'bAddMin({})'.format(__file__),
            'bEcho({})'.format(__file__),
            'bDebug({})'.format(__file__),
            ]
    stickyValues = [
            False,
            False,
            False,
            True,
            True,
            iDotDecPlaces_Default,
            11,
            True,
            True,
            True,
            False,
    ] # Default values.
    for i, stickyKey in enumerate(stickyKeys):
        if sc.sticky.has_key(stickyKey): stickyValues[i] = sc.sticky[stickyKey]
    (
            bIncludeEdges,
            bFineMesh,
            bAddMarks,
            bAddLine,
            bAddDot,
            iDotDecPlaces,
            iDotFontHt,
            bAddMax,
            bAddMin,
            bEcho,
            bDebug,
    ) = stickyValues
    
    ### This section will be skipped until, if ever, the script supports polyface breps.
    #    # Get selection type.
    #    
    #    gopt = ri.Custom.GetOption()
    #    gopt.EnableTransparentCommands(False) # If not used, commands will run when their aliases are entered.
    #    gopt.SetCommandPrompt("Selection type")
    #    sSelectionTypes = 'SingleFace', 'EntireBreps'
    #    gopt.SetDefaultString(sSelectionTypes[0])
    #    for s in sSelectionTypes : gopt.AddOption(s)
    #    
    #    res = gopt.Get()
    #    if res == ri.GetResult.Cancel: return None
    #    if res == ri.GetResult.Option: sSelectionType = gopt.Option().EnglishName
    #    else: sSelectionType = gopt.StringResult()
    #    
    #    bEntireBreps = bool(sSelectionTypes.index(sSelectionType))
    
    # Get 2 rgBrepFaces with optional input.
    
    def addOptions():
        go.AddOptionToggle('IncludeEdges', optT_bIncludeEdges)
        go.AddOptionToggle('FineMesh', optT_bFineMesh)
        go.AddOptionToggle('AddMarks', optT_bAddMarks)
        if bAddMarks:
            go.AddOptionToggle('AddLine', optT_bAddLine)
            go.AddOptionToggle('AddDot', optT_bAddDot)
        if bAddDot:
            go.AddOptionInteger('DotDecPlaces', optI_nDotDecPlaces)
            go.AddOptionInteger('DotFontHt', optI_iDotFontHt)
        if bAddMarks:
            go.AddOptionToggle('AddMax', optT_bAddMax)
            go.AddOptionToggle('AddMin', optT_bAddMin)
    #        go.AddOptionDouble('MaxDistToAccept', optD_fDist_maxToAccept)
    #        go.AddOptionDouble('MaxTol', optD_fDist_maxTol)
    #        go.AddOptionDouble('MinTol', optD_fDist_minTol)
        go.AddOptionToggle('Echo', optT_bEcho)
        go.AddOptionToggle('Debug', optT_bDebug)
    
    go = ri.Custom.GetObject()
    
    #go.SetCommandPrompt("Select 2 faces")
    #go.GeometryFilter = rd.ObjectType.Surface
    
    go.SetCommandPrompt("Select 2 breps")
    go.GeometryFilter = rd.ObjectType.Brep
    
    optT_bIncludeEdges = ri.Custom.OptionToggle(bIncludeEdges, 'No', 'Yes')
    optT_bFineMesh = ri.Custom.OptionToggle(bFineMesh, 'No', 'Yes')
    optT_bAddMarks = ri.Custom.OptionToggle(bAddMarks, 'No', 'Yes')
    optT_bAddLine = ri.Custom.OptionToggle(bAddLine, 'No', 'Yes')
    optT_bAddDot = ri.Custom.OptionToggle(bAddDot, 'No', 'Yes')
    optI_nDotDecPlaces = ri.Custom.OptionInteger(iDotDecPlaces, True, 0)
    optI_iDotFontHt = ri.Custom.OptionInteger(iDotFontHt, True, 3)
    optT_bAddMax = ri.Custom.OptionToggle(bAddMax, 'No', 'Yes')
    optT_bAddMin = ri.Custom.OptionToggle(bAddMin, 'No', 'Yes')
    optT_bEcho = ri.Custom.OptionToggle(bEcho, 'No', 'Yes')
    optT_bDebug = ri.Custom.OptionToggle(bDebug, 'No', 'Yes')
    addOptions()
    
    go.DisablePreSelect()
    #    go.GroupSelect = True
    
    print "First brep set is from which the sampled points will be projected."
    
    while True:
        if sc.escape_test(False): return
        
        res = go.GetMultiple(minimumNumber=2, maximumNumber=2)
        
        if res == ri.GetResult.Cancel:
            return # Esc key was pressed.
        elif res == ri.GetResult.Option:
            bIncludeEdges = optT_bIncludeEdges.CurrentValue
            bFineMesh = optT_bFineMesh.CurrentValue
            bAddMarks = optT_bAddMarks.CurrentValue
            bAddLine = optT_bAddLine.CurrentValue
            bAddDot = optT_bAddDot.CurrentValue
            iDotDecPlaces = optI_nDotDecPlaces.CurrentValue
            iDotFontHt = optI_iDotFontHt.CurrentValue
            bAddMax = optT_bAddMax.CurrentValue
            bAddMin = optT_bAddMin.CurrentValue
            bEcho = optT_bEcho.CurrentValue
            bDebug = optT_bDebug.CurrentValue
        else: break
        
        # Save sticky.
        stickyValues = (
                bIncludeEdges,
                bFineMesh,
                bAddMarks,
                bAddLine,
                bAddDot,
                iDotDecPlaces,
                iDotFontHt,
                bAddMax,
                bAddMin,
                bEcho,
                bDebug
        )
        for i, stickyKey in enumerate(stickyKeys):
            sc.sticky[stickyKey] = stickyValues[i]
        
        go.ClearCommandOptions()
        addOptions()
    
    #    rgFaces = []
    #    for objref in go.Objects():
    #        idxFace = objref.GeometryComponentIndex.Index
    #        if idxFace == -1: idxFace = 0 # For monoface breps.
    #        rgFaces.append(objref.Object().BrepGeometry.Faces[idxFace])
    
    rgBreps = [objref.Object().BrepGeometry for objref in go.Objects()]
    
    go.Dispose()
    
    #    return (rgFaces[0], rgFaces[1],
    #            bAddLine,
    #            bAddDot, iDotDecPlaces, iDotFontHt,
    #            bAddMax, bAddMin)
    
    return (
            rgBreps[0],
            rgBreps[1],
            bIncludeEdges,
            bFineMesh,
            bAddMarks and bAddLine,
            bAddMarks and bAddDot,
            iDotDecPlaces,
            iDotFontHt,
            bAddMax,
            bAddMin,
            bEcho,
            bDebug,
    )


def createMeshingParameters(bFineMesh=False):
    if Rhino.RhinoApp.ExeVersion >= 6:
        rgMeshParams = rg.MeshingParameters.DefaultAnalysisMesh
        if bFineMesh:
            rgMeshParams = rg.MeshingParameters.QualityRenderMesh
        else:
            rgMeshParams = rg.MeshingParameters.FastRenderMesh
    else:
        if bFineMesh:
            rgMeshParams = rg.MeshingParameters.Smooth
        else:
            rgMeshParams = rg.MeshingParameters.Coarse
    #rgMeshParams = rg.MeshingParameters.Default
    #rgMeshParams = rg.MeshingParameters.Minimal
    rgMeshParams.MaximumEdgeLength = 1000.0*sc.doc.ModelAbsoluteTolerance
    rgMeshParams.MinimumEdgeLength = sc.doc.ModelAbsoluteTolerance
    rgMeshParams.MinimumTolerance = 0.1*sc.doc.ModelAbsoluteTolerance
    rgMeshParams.SimplePlanes = False
    return rgMeshParams


def getPointsOnBrep(ObjA, rgMeshParams=None, bFineMesh=False, bDebug=False):
    """
    """
    
    rgBrepA = xBrep.coerceBrep(ObjA)
    if not rgBrepA: return
    
    if rgMeshParams is None: rgMeshParams = createMeshingParameters(bFineMesh=bFineMesh)
    
    # Get vertices of mesh from Brep A
    rgMeshesA = rg.Mesh.CreateFromBrep(rgBrepA, rgMeshParams)
    
    if not rgMeshesA:
        print "No meshes were extracted for single face."
        return
    elif len(rgMeshesA) > 1:
        if bDebug: sEval = 'len(rgMeshesA)'; print sEval+':', eval(sEval)
        
        rgMesh_Joined = rg.Mesh()
        for mesh in rgMeshesA: rgMesh_Joined.Append(mesh)
        rgMeshA = rgMesh_Joined
    else:
        rgMeshA = rgMeshesA[0]
    
    if bDebug:
        pass
    #    sc.doc.Objects.AddMesh(rgMeshA)
    #    sc.doc.Views.Redraw()
    #    return
    
    
    # Find closest points of mesh A on Brep A for better accuracy when Brep A is compared to Brep B.
    
    rgVerticesA = rgMeshA.Vertices
    if bDebug: print "Post CombineIdentical Mesh A vertex count: {}".format(rgVerticesA.Count)
    rgVerticesA.CombineIdentical(ignoreNormals=True, ignoreAdditional=True)
    if bDebug: print "Post CombineIdentical Mesh A vertex count: {}".format(rgVerticesA.Count)
    pt3ds_MeshA = rgVerticesA.ToPoint3dArray()
    
    # Mesh vertices are single precision.
    # Determine whether points should be pulled to face to obtain double precision.
    # Example:
    #     C. Maximum coordinate of all vertices == 1000.0
    #     T. ModelAbsoluteTolerance == 0.005
    #     (Required decimals) = (C whole places) + (T places) + 1 [for extra magnitude of accuracy]
    #     4 + 3 + 1 == 8 (> 7, so need double)
    maxCoord = max([pt.MaximumCoordinate for pt in pt3ds_MeshA])
    iCt_decPlaceWhole = 1 + int(
            math.floor(math.log10(abs(maxCoord)))); #print iCt_decPlaceWhole
    iCt_decPlaceFract = abs(int(
            math.floor(math.log10(abs(sc.doc.ModelAbsoluteTolerance))))); #print iCt_decPlaceFract
    bDoublePrec = True if (iCt_decPlaceWhole + iCt_decPlaceFract + 1) > 7 else False
    
    pt3ds_BrepA = []
    fDistances = []
    
    if bDoublePrec:
        # Closest points on Brep A to Mesh A vertices.
        for pt3d_MeshA in pt3ds_MeshA:
            sc.escape_test()
            #sc.doc.Objects.AddPoint(pt3d_MeshA)
            pt3d_BrepA = rgBrepA.ClosestPoint(pt3d_MeshA)
            #sc.doc.Objects.AddPoint(pt3d_BrepA)
            pt3ds_BrepA.append(pt3d_BrepA)
            if bDebug:
                fDistance = pt3d_MeshA.DistanceTo(pt3d_BrepA)
                fDistances.append(fDistance)
        if bDebug:
            sEval='bDoublePrec'; print sEval+':',eval(sEval)
            sEval='max(fDistances)'; print "Mesh to brep "+sEval+':',eval(sEval)
            sEval='min(fDistances)'; print "Mesh to brep "+sEval+':',eval(sEval)
    else:
        pt3ds_BrepA = pt3ds_MeshA
    
    return pt3ds_BrepA


def getDistancesBetweenBrepFaces(ObjA, ObjB, rgMeshParams=None, bCalcBrepIntersection=True, bDebug=False):
    """
    Not an exact translation of Curve.GetDistancesBetweenCurves for brep faces.
    Accuracy is about 6 decimal places.
    Values at indices 2, 3, 5, and 6 are Pt3ds, not parameter values.
    
    Parameters:
        objA: GUID of monoface brep, monoface rdbrep,
                monoface rgBrep, rgBrepFace, or rgSurface
        objB
        rgMeshParams: Rhino.Geometry.MeshingParameters
    Returns:
        distancesBetweenBrepFaces: Tuple of:
            0: True or False based on success or failure, respectively.
            1: Maximum distance.
            2: Maximum distance point on brep A.
            3: Maximum distance point on brep B.
            4: Minimum distance.
            5: Minimum distance point on brep A.
            6: Minimum distance point on brep B.
    """
    
    distancesBetweenBrepFaces = [False, None, None, None, None, None, None]
    
    rgBrepA = xBrep.coerceBrep(ObjA)
    if not rgBrepA: return tuple(distancesBetweenBrepFaces)
    if rgBrepA.Faces.Count != 1: return tuple(distancesBetweenBrepFaces)
    
    rgBrepB = xBrep.coerceBrep(ObjB)
    if not rgBrepB: return tuple(distancesBetweenBrepFaces)
    if rgBrepB.Faces.Count != 1: return tuple(distancesBetweenBrepFaces)
    
    # Get vertices of mesh from Brep A
    rgMeshesA = rg.Mesh.CreateFromBrep(rgBrepA, rgMeshParams)
    
    #sEval = 'len(rgMeshesA)'; print sEval + ':', eval(sEval)
    if not rgMeshesA:
        print "No meshes were extracted for single face."
        return tuple(distancesBetweenBrepFaces)
    elif len(rgMeshesA) > 1:
        print "More than 1 mesh was extracted for single face.  Check this."
        return tuple(distancesBetweenBrepFaces)
    
    rgMeshA = rgMeshesA[0]
    #    sc.doc.Objects.AddMesh(rgMeshA)
    #    sc.doc.Views.Redraw()
    #    return tuple(distancesBetweenBrepFaces)
    
    if bDebug:
        print "Mesh A vertex count: {}".format(rgMeshA.Vertices.Count)
    
    # Find closest points of mesh A on Brep A for better accuracy when Brep A is compared to Brep B.
    
    pt3ds_MeshA = rgMeshA.Vertices.ToPoint3dArray()
    
    pt3ds_BrepA = []
    fDistances = []
    
    # Closest points on Brep A to Mesh A vertices.
    # If script runs too slow, this step may be skipped, and closest points on Brep B can be calculated, but with less accuracy.
    for pt3d_MeshA in pt3ds_MeshA:
        sc.escape_test()
        pt3d_BrepA = rgBrepA.ClosestPoint(pt3d_MeshA)
        pt3ds_BrepA.append(pt3d_BrepA)
    #        fDistance = pt3d_MeshA.DistanceTo(pt3d_BrepA)
    #        fDistances.append(fDistance)
    
    #    sEval = 'max(fDistances)'; print sEval + ':', eval(sEval)
    #    sEval = 'min(fDistances)'; print sEval + ':', eval(sEval)
    
    pt3ds_BrepB = []
    fDistances = []
    
    # Closest points on Brep B to points on Brep A.
    for pt3d_BrepA in pt3ds_BrepA:
        sc.escape_test()
        pt3d_BrepB = rgBrepB.ClosestPoint(pt3d_BrepA)
        pt3ds_BrepB.append(pt3d_BrepB)
        fDistance = pt3d_BrepA.DistanceTo(pt3d_BrepB)
        fDistances.append(fDistance)
    
    # Calculate maximum distance.
    fDist_Max = max(fDistances)
    idxMax = fDistances.index(fDist_Max)
    distancesBetweenBrepFaces[0] = True
    distancesBetweenBrepFaces[1] = fDist_Max
    distancesBetweenBrepFaces[2] = pt3ds_BrepA[idxMax]
    distancesBetweenBrepFaces[3] = pt3ds_BrepB[idxMax]
    
    
    # Calculate minimum distance.
    
    # Check whether breps intersect and set minimums accordingly.
    if bCalcBrepIntersection:
        rc = rg.Intersect.Intersection.BrepBrep(
                brepA = rgBrepA,
                brepB = rgBrepB,
                tolerance = 0.1*sc.doc.ModelAbsoluteTolerance)
        if rc[0]:
            rgPt3ds_intrsct = rc[2]
            if rgPt3ds_intrsct:
                distancesBetweenBrepFaces[0] = True
                distancesBetweenBrepFaces[4] = 0.0
                distancesBetweenBrepFaces[5] = rgPt3ds_intrsct[0]
                distancesBetweenBrepFaces[6] = rgPt3ds_intrsct[0]
            else:
                for rgCrv_intrsct in rc[1]:
                    if rgCrv_intrsct.IsValid:
                        distancesBetweenBrepFaces[0] = True
                        distancesBetweenBrepFaces[4] = 0.0
                        distancesBetweenBrepFaces[5] = rgCrv_intrsct.PointAtStart
                        distancesBetweenBrepFaces[6] = rgCrv_intrsct.PointAtStart
                        break
    
    # If intersection was not found, calculate minimum distance as done for maximum distance.
    if distancesBetweenBrepFaces[4] is None:
        fDist_Min = min(fDistances)
        idxMin = fDistances.index(fDist_Min)
        distancesBetweenBrepFaces[4] = fDist_Min
        distancesBetweenBrepFaces[5] = pt3ds_MeshA[idxMin]
        distancesBetweenBrepFaces[6] = pt3ds_BrepB[idxMin]
    
    return tuple(distancesBetweenBrepFaces)


def getDistancesBetweenBreps(ObjA, ObjB, bIncludeEdges=False, rgMeshParams=None, bFineMesh=False, bCalcBrepIntersection=True, bDebug=False):
    """
    Not an exact translation of Curve.GetDistancesBetweenCurves for breps.
    Accuracy is about 6 decimal places.
    Values at indices 2, 3, 5, and 6 are Pt3ds, not parameter values.
    
    Parameters:
        objA: GUID of Brep, BrepObject, Brep geometry, rgBrepFace, or rgSurface
        objB
        rgMeshParams: Rhino.Geometry.MeshingParameters
    Returns:
        distancesBetweenBrepFaces: Tuple of:
            0: True or False based on success or failure, respectively.
            1: Maximum distance.
            2: Maximum distance point on brep A.
            3: Maximum distance point on brep B.
            4: Minimum distance.
            5: Minimum distance point on brep A.
            6: Minimum distance point on brep B.
    """
    
    if rgMeshParams is None: rgMeshParams = createMeshingParameters(bFineMesh=bFineMesh)
    
    distancesBetweenBrepFaces = [False, None, None, None, None, None, None]
    
    rgBrepA = xBrep.coerceBrep(ObjA)
    if not rgBrepA: return tuple(distancesBetweenBrepFaces)
    
    rgBrepB = xBrep.coerceBrep(ObjB)
    if not rgBrepB: return tuple(distancesBetweenBrepFaces)
    
    pt3ds_BrepA = getPointsOnBrep(
            ObjA=rgBrepA,
            rgMeshParams=rgMeshParams,
            bFineMesh=bFineMesh,
            bDebug=bDebug,
    )
    if pt3ds_BrepA is None: return tuple(distancesBetweenBrepFaces)
    
    if bDebug: sEval = 'len(pt3ds_BrepA)'; print sEval+':', eval(sEval)
    
    pt3ds_BrepB = []
    fDistances = []
    
    stopwatch.Restart()
    
    # Closest points on Brep B to points on Brep A.
    if bIncludeEdges:
        for pt3d_BrepA in pt3ds_BrepA:
            sc.escape_test()
            pt3d_BrepB = rgBrepB.ClosestPoint(pt3d_BrepA)
            pt3ds_BrepB.append(pt3d_BrepB)
            fDistance = pt3d_BrepA.DistanceTo(pt3d_BrepB)
            fDistances.append(fDistance)
        
        stopwatch.Stop()
        if bDebug: print "All ClosestPoints of A to B: {} seconds".format(stopwatch.Elapsed.TotalSeconds)
    else:
        for pt3d_BrepA in pt3ds_BrepA:
            pt3ds_BrepB.append(None)
            fDistances.append(None)
            for iF, face in enumerate(rgBrepB.Faces):
                rc = face.PullPointsToFace(
                        points=[pt3d_BrepA],
                        tolerance=0.1*sc.doc.ModelAbsoluteTolerance,
                )
                if not rc: continue
                pt3d_BrepB = rc[0]
                fDistance = pt3d_BrepA.DistanceTo(pt3d_BrepB)
                if pt3ds_BrepB[-1] is None or fDistance < fDistances[-1]:
                    pt3ds_BrepB[-1] = pt3d_BrepB
                    fDistances[-1] = fDistance
        
        stopwatch.Stop()
        if bDebug: print "All PullPointsToFace of A to B: {} seconds".format(stopwatch.Elapsed.TotalSeconds)
    
    if bDebug: sEval = 'len(pt3ds_BrepB)'; print sEval+':', eval(sEval)
    
    # Calculate maximum distance.
    fDist_Max = max(fDistances)
    idxMax = fDistances.index(fDist_Max)
    distancesBetweenBrepFaces[0] = True
    distancesBetweenBrepFaces[1] = fDist_Max
    distancesBetweenBrepFaces[2] = pt3ds_BrepA[idxMax]
    distancesBetweenBrepFaces[3] = pt3ds_BrepB[idxMax]
    
    
    # Calculate minimum distance.
    
    fDist_Min = min(fDistances)
    fDist_Min = min(d for d in fDistances if d is not None)
    if bDebug: sEval = 'fDist_Min'; print sEval+':', eval(sEval)
    idxMin = fDistances.index(fDist_Min)
    distancesBetweenBrepFaces[4] = fDist_Min
    distancesBetweenBrepFaces[5] = pt3ds_BrepA[idxMin]
    distancesBetweenBrepFaces[6] = pt3ds_BrepB[idxMin]
    
    if fDist_Min > sc.doc.ModelAbsoluteTolerance:
        if bCalcBrepIntersection:
            # Check whether breps intersect and adjust minimums accordingly.
            rc = rg.Intersect.Intersection.BrepBrep(
                    brepA = rgBrepA,
                    brepB = rgBrepB,
                    tolerance = 0.1*sc.doc.ModelAbsoluteTolerance)
            if rc[0]:
                rgPt3ds_intrsct = rc[2]
                if rgPt3ds_intrsct:
                    distancesBetweenBrepFaces[0] = True
                    distancesBetweenBrepFaces[4] = 0.0
                    distancesBetweenBrepFaces[5] = rgPt3ds_intrsct[0]
                    distancesBetweenBrepFaces[6] = rgPt3ds_intrsct[0]
                else:
                    for rgCrv_intrsct in rc[1]:
                        if rgCrv_intrsct.IsValid:
                            distancesBetweenBrepFaces[0] = True
                            distancesBetweenBrepFaces[4] = 0.0
                            distancesBetweenBrepFaces[5] = rgCrv_intrsct.PointAtStart
                            distancesBetweenBrepFaces[6] = rgCrv_intrsct.PointAtStart
                            break
    
    return tuple(distancesBetweenBrepFaces)


def isMaximumDistanceBetweenBrepsWithinTolerance(objForBrepA, objForBrepB, fTolerance, rgMeshParams=None, bFineMesh=False, bDebug=False):
    """
    Parameters:
        objForBrepA: GUID of monoface brep, monoface rdbrep,
                monoface rgBrep, rgBrepFace, or rgSurface
        objForBrepB
        fTolerance
        rgMeshParams: Rhino.Geometry.MeshingParameters
    Returns:
        Maximum deviation if maximum deviation of brep faces is within provided tolerance.
        False if maximum deviation of brep faces is not within provided tolerance.
        None on error.
    """
    
    rgBrepA = xBrep.coerceBrep(objForBrepA)
    if not rgBrepA: return
    
    rgBrepB = xBrep.coerceBrep(objForBrepB)
    if not rgBrepB: return
    
    if rgMeshParams is None: rgMeshParams = createMeshingParameters(bFineMesh=bFineMesh)
    
    # Get vertices of mesh from Brep A
    rgMeshesA = rg.Mesh.CreateFromBrep(rgBrepA, rgMeshParams)
    
    #sEval = 'len(rgMeshesA)'; print sEval + ':', eval(sEval)
    if not rgMeshesA:
        print "No meshes were extracted for single face."
        return
    elif len(rgMeshesA) > 1:
        print "More than 1 mesh was extracted for single face.  Check this."
        return
    
    rgMeshA = rgMeshesA[0]
    #    sc.doc.Objects.AddMesh(rgMeshA)
    #    sc.doc.Views.Redraw()
    #    return
    
    if bDebug:
        print "Mesh A vertex count: {}".format(rgMeshA.Vertices.Count)
    
    # Find closest points of mesh A on Brep A for better accuracy when Brep A is compared to Brep B.
    
    pt3ds_MeshA = rgMeshA.Vertices.ToPoint3dArray()
    
    fDistances = []
    
    # Get closest points on Brep A to Mesh A vertices then
    # closest points of the former on Brep B.
    for pt3d_MeshA in pt3ds_MeshA:
        sc.escape_test()
        pt3d_BrepA = rgBrepA.ClosestPoint(pt3d_MeshA)
        pt3d_BrepB = rgBrepB.ClosestPoint(pt3d_BrepA)
        fDistance = pt3d_BrepB.DistanceTo(pt3d_BrepA)
        if fDistance > fTolerance:
            return False
        fDistances.append(fDistance)
    
    return max(fDistances)


def addMarks(distancesBetweenBrepFaces, bAddLine=True, bAddDot=True, iDotDecPlaces=iDotDecPlaces_Default, iDotFontHt=11, bAddMax=True, bAddMin=True, bDebug=False):
    """
    """
    
    if bAddDot:
        def addTextDot(text, pt, iDotFontHt=14):
            rgDot = rg.TextDot(text, pt)
            rgDot.FontHeight = iDotFontHt
            sc.doc.Objects.AddTextDot(rgDot)
    
    attr_Line = rd.ObjectAttributes()
    attr_Line.LayerIndex = sc.doc.Layers.CurrentLayerIndex # If not done, layer of index 0 will be used.
    attr_Line.ObjectDecoration = rd.ObjectDecoration.BothArrowhead
    
    # Maximum deviation.
    if bAddMax:
        if distancesBetweenBrepFaces[1] == 0:
            pass
        elif round(distancesBetweenBrepFaces[1], iDotDecPlaces) != 0:
            if bAddLine:
                sc.doc.Objects.AddLine(distancesBetweenBrepFaces[2],
                        distancesBetweenBrepFaces[3], attr_Line)
            if bAddDot:
                addTextDot('{0:.{1}f}'.format(
                        distancesBetweenBrepFaces[1], iDotDecPlaces),
                        (distancesBetweenBrepFaces[2] +
                        distancesBetweenBrepFaces[3]) / 2.0, iDotFontHt)
    
    # Minimum deviation.
    if bAddMin:
        if distancesBetweenBrepFaces[4] == 0:
            pass
        elif round(distancesBetweenBrepFaces[4], iDotDecPlaces) != 0:
            if bAddLine:
                sc.doc.Objects.AddLine(distancesBetweenBrepFaces[5],
                        distancesBetweenBrepFaces[6], attr_Line)
            if bAddDot:
                addTextDot('{0:.{1}f}'.format(
                        distancesBetweenBrepFaces[4], iDotDecPlaces),
                        (distancesBetweenBrepFaces[5] +
                        distancesBetweenBrepFaces[6]) / 2.0, iDotFontHt)
        elif (distancesBetweenBrepFaces[5]
                and int(1000 * distancesBetweenBrepFaces[1]) != 0):
            # Also checking maximum distance because if both max. and min.
            # are 0, no geometry should be added.
            if bAddLine:
                sc.doc.Objects.AddPoint(distancesBetweenBrepFaces[5])


def main():
    
    rc = getInput()
    if rc is None: return
    (
            rgFaceA,
            rgFaceB,
            bIncludeEdges,
            bFineMesh,
            bAddLine,
            bAddDot,
            iDotDecPlaces,
            iDotFontHt,
            bAddMax,
            bAddMin,
            bEcho,
            bDebug,
    ) = rc
    
    rs.Prompt("Working ...")
    
    # Simpler object getter for monoface breps.
    #    gFaceA = rs.GetObject("Select face A",
    #            filter=rs.filter.surface, preselect=True)
    #    if not gFaceA: return
    #    
    #    gFaceB = gFaceA
    #    while gFaceB == gFaceA:
    #        gFaceB = rs.GetObject("Select face B", filter=rs.filter.surface)
    #    if not gFaceB: return
    #    
    #    rgBrepA = rs.coercegeometry(gFaceA)
    #    rgBrepB = rs.coercegeometry(gFaceB)
    #    
    #    rgFaceA = rs.coercesurface(gFaceA)
    #    rgFaceB = rs.coercesurface(gFaceB)
    
    distancesBetweenBrepFaces = getDistancesBetweenBreps(
            rgFaceA,
            rgFaceB,
            bIncludeEdges,
            rgMeshParams=None,
            bFineMesh=bFineMesh,
            bDebug=bDebug
    )
    if not distancesBetweenBrepFaces[0]: return
    
    if bAddLine or bAddDot:
        addMarks(
                distancesBetweenBrepFaces=distancesBetweenBrepFaces,
                bAddLine=bAddLine,
                bAddDot=bAddDot,
                iDotDecPlaces=iDotDecPlaces,
                iDotFontHt=iDotFontHt,
                bAddMax=bAddMax,
                bAddMin=bAddMin,
                bDebug=bDebug,
        )
    
    if (
            distancesBetweenBrepFaces[1] is None
            and
            distancesBetweenBrepFaces[4] is None
    ):
        s  = "Faces do not overlap."
    else:
        s  = "Maximum deviation = {0:.{1}f}".\
                format(
                        distancesBetweenBrepFaces[1],
                        sc.doc.ModelDistanceDisplayPrecision+1)
        s += "\nMinimum deviation = {0:.{1}f}".\
                format(
                        distancesBetweenBrepFaces[4],
                        sc.doc.ModelDistanceDisplayPrecision+1)
    print s
    
    sc.doc.Views.Redraw()


if __name__ == '__main__': main()