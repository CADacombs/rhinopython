"""
171207-11: Created, starting with rebuildCurveUniform.py
...
190128: Fixed crash during some output.
190304: Added an import to replace an embedded function.  Updated an import name.
        Fixed bug where the test surface with the greatest number of control points was not considered for final 
190507: Changed some options.
190509: Updated an import name.
190510: Refactored.  Improved main routine.
190519: Updated an import name.
190629: Add Opts.  Now will replace monoface breps if that option is enabled.
190807: Uncommented code that rejects surfaces that are already uniform.
190810: Now will first remove all interior knots.
        Added support for some surface properties filter options.
190814: Bug fix.  Import-related update.
190901: Modified some debug feedback.
191031-0619: Import-related updates.  Bug fix.
"""

import Rhino
import Rhino.DocObjects as rd
import Rhino.Geometry as rg
import Rhino.Input as ri
import scriptcontext as sc

from System import Guid

import xBrep_getDistancesBetween2
import xBrepFace
import xBrepObject
import xKnotList
import xNurbsSurface


sOpts = (
        'fDevTol',
        'bShrinkFirst',
        'bTryDegree1',
        'iMaxDegree',
        'iMaxCpCtEachDir',
        'bPlane',
        'bRev',
        'bSum',
        'bUniform',
        'bBezier',
        'bRational',
        'b1DirForRational',
        'bReplace',
        'bExtract',
        'bEcho',
        'bDebug',
)


class Opts:
    
    keys = []
    values = {}
    names = {}
    riOpts = {}
    stickyKeys = {}
    
    for key in sOpts:
        keys.append(key)
        names[key] = key[1:] # Overwrite as wanted in the following.
    
    key = 'fDevTol'
    values[key] = 0.1 * sc.doc.ModelAbsoluteTolerance
    riOpts[key] = ri.Custom.OptionDouble(initialValue=values[key], setLowerLimit=True, limit=0.0)
    stickyKeys[key] = '{}({})({})'.format(key, __file__, sc.doc.Name)
    
    key = 'bShrinkFirst'
    values[key] = True
    riOpts[key] = ri.Custom.OptionToggle(values[key], offValue='No', onValue='Yes')
    stickyKeys[key] = '{}({})'.format(key, __file__)
    
    key = 'bTryDegree1'
    values[key] = True
    riOpts[key] = ri.Custom.OptionToggle(initialValue=values[key], offValue='No', onValue='Yes')
    stickyKeys[key] = '{}({})'.format(key, __file__)
    
    key = 'iMaxDegree'
    values[key] = 3
    riOpts[key] = ri.Custom.OptionInteger(initialValue=values[key])
    stickyKeys[key] = '{}({})'.format(key, __file__)
    
    key = 'iMaxCpCtEachDir'
    values[key] = 20
    riOpts[key] = ri.Custom.OptionInteger(initialValue=values[key])
    stickyKeys[key] = '{}({})'.format(key, __file__)
    
    key = 'bPlane'
    values[key] = False
    names[key] = 'RebuildPlaneSrf'
    riOpts[key] = ri.Custom.OptionToggle(initialValue=values[key], offValue='No', onValue='Yes')
    stickyKeys[key] = '{}({})'.format(key, __file__)
    
    key = 'bRev'
    values[key] = False
    riOpts[key] = ri.Custom.OptionToggle(initialValue=values[key], offValue='No', onValue='Yes')
    stickyKeys[key] = '{}({})'.format(key, __file__)
    
    key = 'bSum'
    values[key] = False
    riOpts[key] = ri.Custom.OptionToggle(initialValue=values[key], offValue='No', onValue='Yes')
    stickyKeys[key] = '{}({})'.format(key, __file__)
    
    key = 'bUniform'
    values[key] = False
    riOpts[key] = ri.Custom.OptionToggle(initialValue=values[key], offValue='No', onValue='Yes')
    stickyKeys[key] = '{}({})'.format(key, __file__)
    
    key = 'bBezier'
    values[key] = False
    riOpts[key] = ri.Custom.OptionToggle(initialValue=values[key], offValue='No', onValue='Yes')
    stickyKeys[key] = '{}({})'.format(key, __file__)
    
    key = 'bRational'
    values[key] = False
    names[key] = 'Rational'
    riOpts[key] = ri.Custom.OptionToggle(initialValue=values[key], offValue='No', onValue='Yes')
    stickyKeys[key] = '{}({})'.format(key, __file__)
    
    key = 'b1DirForRational'
    values[key] = True
    riOpts[key] = ri.Custom.OptionToggle(initialValue=values[key], offValue='No', onValue='Yes')
    stickyKeys[key] = '{}({})'.format(key, __file__)
    
    key = 'bReplace'
    values[key] = True
    names[key] = 'Action'
    riOpts[key] = ri.Custom.OptionToggle(initialValue=values[key], offValue='Add', onValue='Replace')
    stickyKeys[key] = '{}({})'.format(key, __file__)
    
    key = 'bExtract'
    values[key] = False
    riOpts[key] = ri.Custom.OptionToggle(initialValue=values[key], offValue='No', onValue='Yes')
    stickyKeys[key] = '{}({})'.format(key, __file__)
    
    key = 'bEcho'
    values[key] = True
    riOpts[key] = ri.Custom.OptionToggle(initialValue=values[key], offValue='No', onValue='Yes')
    stickyKeys[key] = '{}({})'.format(key, __file__)
    
    key = 'bDebug'
    values[key] = False
    riOpts[key] = ri.Custom.OptionToggle(initialValue=values[key], offValue='No', onValue='Yes')
    stickyKeys[key] = '{}({})'.format(key, __file__)
    
    # Load sticky.
    for key in stickyKeys:
        if stickyKeys[key] in sc.sticky:
            if key in riOpts:
                riOpts[key].CurrentValue = values[key] = sc.sticky[stickyKeys[key]]


    @classmethod
    def setValues(cls):
        for key in sOpts:
            if key in cls.riOpts:
                cls.values[key] = cls.riOpts[key].CurrentValue


    @classmethod
    def saveSticky(cls):
        for key in cls.stickyKeys:
            if key in cls.riOpts:
                sc.sticky[cls.stickyKeys[key]] = cls.riOpts[key].CurrentValue


def getInput():
    """
    Get surfaces with optional input
    """
    
    go = ri.Custom.GetObject()
    
    go.SetCommandPrompt("Select breps and/or faces")
    
    go.GeometryFilter = rd.ObjectType.Brep | rd.ObjectType.Surface
    
    go.AcceptNumber(True, acceptZero=True)
    
    go.DeselectAllBeforePostSelect = False # So objects won't be deselected on repeats of While loop.
    go.EnableClearObjectsOnEntry(False) # Do not clear objects in go on repeats of While loop.
    go.EnableUnselectObjectsOnExit(False) # Do not unselect object when an option selected, a number is entered, etc.
    
    s  = "Degree: 0 will match degree of input surface."
    s += "\tMaxCpCtEachDir: 0 will use the curve's current control point count,"
    s += "  Positive integers are the maximum to allow,"
    s += "  Negative integers will allow any amount."
    print s
    
    bPreselectedObjsChecked = False
    
    while True:
        go.AddOptionDouble(Opts.names['fDevTol'], Opts.riOpts['fDevTol'])
        go.AddOptionToggle(Opts.names['bShrinkFirst'], Opts.riOpts['bShrinkFirst'])
        go.AddOptionToggle(Opts.names['bTryDegree1'], Opts.riOpts['bTryDegree1'])
        if Opts.values['bTryDegree1']:
            go.AddOptionInteger('OtherDegree', Opts.riOpts['iMaxDegree'])
        else:
            go.AddOptionInteger('Degree', Opts.riOpts['iMaxDegree'])
        go.AddOptionInteger(Opts.names['iMaxCpCtEachDir'], Opts.riOpts['iMaxCpCtEachDir'])
        go.AddOptionToggle(Opts.names['bPlane'], Opts.riOpts['bPlane'])
        go.AddOptionToggle(Opts.names['bRev'], Opts.riOpts['bRev'])
        go.AddOptionToggle(Opts.names['bSum'], Opts.riOpts['bSum'])
        go.AddOptionToggle(Opts.names['bUniform'], Opts.riOpts['bUniform'])
        if Opts.values['bUniform']:
            go.AddOptionToggle(Opts.names['bBezier'], Opts.riOpts['bBezier'])
        go.AddOptionToggle(Opts.names['bRational'], Opts.riOpts['bRational'])
        if Opts.values['bRational']:
            go.AddOptionToggle(Opts.names['b1DirForRational'], Opts.riOpts['b1DirForRational'])
        go.AddOptionToggle(Opts.names['bReplace'], Opts.riOpts['bReplace'])
        if Opts.values['bReplace']:
            go.AddOptionToggle(Opts.names['bExtract'], Opts.riOpts['bExtract'])
        go.AddOptionToggle(Opts.names['bEcho'], Opts.riOpts['bEcho'])
        go.AddOptionToggle(Opts.names['bDebug'], Opts.riOpts['bDebug'])
        
        res = go.GetMultiple(minimumNumber=1, maximumNumber=0)
        
        # Use bPreselectedObjsChecked so that only objects before the
        # first call to go.GetMultiple is considered.
        if not bPreselectedObjsChecked and go.ObjectsWerePreselected:
            bPreselectedObjsChecked = True
            go.EnablePreSelect(False, ignoreUnacceptablePreselectedObjects=True)
        elif res == ri.GetResult.Object:
            objrefs = go.Objects()
            go.Dispose()
            return tuple([objrefs] + [Opts.values[key] for key in sOpts])
        elif res == ri.GetResult.Cancel:
            return
        else:
            # An option was selected or a number was entered.
            key = 'fDevTol'
            if res == ri.GetResult.Number:
                Opts.riOpts[key].CurrentValue = go.Number()
            if Opts.riOpts[key].CurrentValue < 0.0:
                Opts.riOpts[key].CurrentValue = Opts.riOpts[key].InitialValue
        
        Opts.setValues()
        Opts.saveSticky()
        go.ClearCommandOptions()


def getNurbsSurfaceChangeDescription(rgNurbsSrf1, rgNurbsSrf2):
    
    s  = "Original surface is a {}.".format(rgNurbsSrf1.GetType().Name)
    
    if rgNurbsSrf2:
        s += "  Prop:I-O"
        s += "  {}:{}x{}-{}x{}".format("Deg",
                rgNurbsSrf1.OrderU-1, rgNurbsSrf1.OrderV-1,
                rgNurbsSrf2.OrderU-1, rgNurbsSrf2.OrderV-1)
        s += "  {}:{}x{}-{}x{}".format("PtCt",
                rgNurbsSrf1.Points.CountU, rgNurbsSrf1.Points.CountV,
                rgNurbsSrf2.Points.CountU, rgNurbsSrf2.Points.CountV)
        s += "  {}:{}x{}-{}x{}".format("IsUniform",
                str(xKnotList.isUniform(rgNurbsSrf1.KnotsU))[0],
                str(xKnotList.isUniform(rgNurbsSrf1.KnotsV))[0],
                str(xKnotList.isUniform(rgNurbsSrf2.KnotsU))[0],
                str(xKnotList.isUniform(rgNurbsSrf2.KnotsV))[0])
        s += "  {}:{}-{}".format("IsRational",
                str(rgNurbsSrf1.IsRational)[0],
                str(rgNurbsSrf2.IsRational)[0])
        s += "  {}:{}x{}-{}x{}".format("IsClosed",
                str(rgNurbsSrf1.IsClosed(0))[0],
                str(rgNurbsSrf1.IsClosed(1))[0],
                str(rgNurbsSrf2.IsClosed(0))[0],
                str(rgNurbsSrf2.IsClosed(1))[0])
        if (    rgNurbsSrf1.IsClosed(0) or rgNurbsSrf1.IsClosed(1) or
                rgNurbsSrf2.IsClosed(0) or rgNurbsSrf2.IsClosed(1)):
            s += "  {}:{}-{}".format("IsPeriodic",
                    str(rgNurbsSrf1.IsPeriodic)[0],
                    str(rgNurbsSrf2.IsPeriodic)[0])
    return s


def isSurfaceValidForConversion(rgSrf0, bPlane=False, bRev=False, bSum=True, bUniform=False, bBezier=False, bRational=True):
    """
    return tuple of bool and string (log) or None)
    """
    
    if not bPlane and isinstance(rgSrf0, rg.PlaneSurface):
        return False, "PlaneSurface skipped."
    elif not bRev and isinstance(rgSrf0, rg.RevSurface):
        return False, "RevSurface skipped."
    elif not bSum and isinstance(rgSrf0, rg.SumSurface):
        return False, "SumSurface skipped."
    elif not bRational and rgSrf0.IsRational:
        return False, "Rational surface skipped."
        
    if isinstance(rgSrf0, rg.NurbsSurface):
        if (
                not bUniform
                and (
                    xKnotList.isUniform(rgSrf0.KnotsU)
                    and
                    xKnotList.isUniform(rgSrf0.KnotsV)
                )
        ):
            return False, "Uniform surface skipped."
        
        if (
                bUniform
                and
                not bBezier
                and rgSrf0.SpanCount(0) == 1
                and rgSrf0.SpanCount(1) == 1
        ):
            return False, "NurbsSurface(s) don't have interior knots."
    
    return True, None


def processSurface(rgSrf0, fDevTol=0.1*sc.doc.ModelAbsoluteTolerance, bTryDegree1=True, iMaxDegree=3, iMaxCpCtEachDir=20, bPlane=False, bRev=False, bSum=True, bUniform=False, bBezier=False, bRational=False, b1DirForRational=True, bEcho=True, bDebug=False):
    """Returns surface of each degree of min. CP count and the deviation from original surface."""
    
    rc = isSurfaceValidForConversion(
            rgSrf0=rgSrf0,
            bPlane=bPlane,
            bRev=bRev,
            bSum=bSum,
            bUniform=bUniform,
            bBezier=bBezier,
            bRational=bRational,
    )
    if not rc[0]: return None, rc[1]
    
    # Get NurbsSurface for main method.
    if isinstance(rgSrf0, rg.NurbsSurface):
        rgNurbsSrf1 = rgSrf0.Duplicate()
    else:
        rgNurbsSrf1 = rgSrf0.ToNurbsSurface()
        if not rgNurbsSrf1:
            return None, "NurbsSurface could not be constructed from {}.".format(rdSurface_or_rgEdge)
    
    
    if b1DirForRational:
        print "Rebuild1DirForRational not supported yet." \
              "  Will attempt to rebuild complete."
    
    
    def getBestSurfaceForDegreeCombo():
        
        sDegrees = "  {}:{}x{}".format("Deg", iDeg_U, iDeg_V)
        
        # Assign maximum number of control points to test.
        if iDeg_U == 1:
            iCpCt_U_Max = 2
        else:
            iCpCt_U_Max = iMaxCpCtEachDir
        
        if iDeg_V == 1:
            iCpCt_V_Max = 2
        else:
            iCpCt_V_Max = iMaxCpCtEachDir
        
        nPtCt_Max = iCpCt_U_Max * iCpCt_V_Max
        
        #
        # First, try the greatest numbers of control points.
        # If pass, start processing from lowest numbers of control points.
        # If fail, don't process any more from this degree x degree.
        
        iCpCt_U = iCpCt_U_Max
        iCpCt_V = iCpCt_V_Max
        
        rc = xNurbsSurface.rebuildUniform(
                rgNurbsSrf1,
                iDeg_U,
                iDeg_V,
                iCpCt_U,
                iCpCt_V)
        if not rc:
            print "Error!  Surface could not be rebuilt!"
            return # To next degree x degree.
        rgNurbsSrf2_MaxCpCt = rc
        
        Rhino.RhinoApp.CommandPrompt = sCmdPrompt0 + sDegrees + "  Testing tolerance of rebuild ..."
        if bDebug:
            sCmdPrompt = Rhino.RhinoApp.CommandPrompt
            print sCmdPrompt
        
        rc = xBrep_getDistancesBetween2.getDistancesBetweenBreps(
                rgNurbsSrf1,
                rgNurbsSrf2_MaxCpCt,
                bIncludeEdges=True,
                rgMeshParams=None,
                bFineMesh=False,
                bCalcBrepIntersection=False,
                bDebug=False
                )
        if not rc[0]:
            rgNurbsSrf2_MaxCpCt.Dispose()
            return
        fDev = rc[1]
        if bDebug: sEval='fDev'; print sEval+': ',eval(sEval)
        if fDev > fDevTol:
            if bDebug:
                s = "No solution exists for degree {}x{}".format(iDeg_U, iDeg_V)
                s += " at maximum allowed control point count, {}x{}.".format(iCpCt_U, iCpCt_V)
                print s
            rgNurbsSrf2_MaxCpCt.Dispose()
            return False # To next degree_combo.
        
        
        # Solution exists for this degree x degree.
        #
        srf_dev_MaxCpCt = fDev_Max = fDev
        
        # Loop through U control point count.
        for iCpCt_U in xrange(iDeg_U+1, iCpCt_U_Max+1):
            sc.escape_test()
            
            #TODO: Divide and conquer iCpCt_V to find the lowest one instead of looping.
            
            # Loop through V control point count.
            for iCpCt_V in xrange(iDeg_V+1, iCpCt_V_Max+1):
                sc.escape_test()
                
                if iDeg_U != 1 and iDeg_V != 1:
                    if iCpCt_V != iCpCt_U: continue
                
                sDegrees = "  {}:{}x{}".format("Deg", iDeg_U, iDeg_V)
                sCpCts = "  {}:{}x{}".format("CpCts", iCpCt_U, iCpCt_V)
                s = sCmdPrompt0 + sDegrees + sCpCts
                if bDebug:
                    print s
                else:
                    Rhino.RhinoApp.CommandPrompt = s
                
                # Skip this iteration when the number of control points
                # are not less than the best found for this degree x degree.
                if iCpCt_U * iCpCt_V >= nPtCt_Max: break # To next U point.
                
                rc = xNurbsSurface.rebuildUniform(
                        rgNurbsSrf1,
                        iDeg_U,
                        iDeg_V,
                        iCpCt_U,
                        iCpCt_V)
                if not rc: continue
                rgNurbsSrf2 = rc
                
                rc = xBrep_getDistancesBetween2.isMaximumDistanceBetweenBrepsWithinTolerance(
                        rgNurbsSrf1,
                        rgNurbsSrf2,
                        fDevTol,
                        bFineMesh=False)
                if rc is None or rc is False: continue # Do not test not rc in case it == 0.0.
                return rgNurbsSrf2, rc
        
        return rgNurbsSrf2_MaxCpCt, srf_dev_MaxCpCt
    
    
    # Loop through all combinations of U and V degrees.
    
    rgNurbsSrfs1 = []; srf_devs = []
    
    if bTryDegree1:
        degree_combos = (1,1), (1,iMaxDegree), (iMaxDegree, 1), (iMaxDegree, iMaxDegree)
    else:
        degree_combos = (iMaxDegree, iMaxDegree),
    
    sCmdPrompt0 = Rhino.RhinoApp.CommandPrompt
    
    for iDeg_U, iDeg_V in degree_combos:
        sc.escape_test()
        
        # Don't bother attempting to replace a closed surface with a linear shape.
        if iDeg_U == 1 and rgNurbsSrf1.IsClosed(0): continue
        if iDeg_V == 1 and rgNurbsSrf1.IsClosed(1): continue
        
        rc = getBestSurfaceForDegreeCombo()
        if rc is None: continue
        elif rc is False: continue
        rgNurbsSrfs1.append(rc[0])
        srf_devs.append(rc[1])
    
    if not rgNurbsSrfs1: return None, "Surface not found."
    
    def surfaceWithLeastPoints():
        
        # Accumulate and pick the surface with lowest point count.
        idxPtCt_Least = 0
        nPtCt_Least = rgNurbsSrfs1[0].Points.CountU * rgNurbsSrfs1[0].Points.CountV
        if len(rgNurbsSrfs1) > 1:
            for i in xrange(2, len(rgNurbsSrfs1)):
                rgNurbsSrf2 = rgNurbsSrfs1[i]
                if rgNurbsSrf2:
                    nPtCt = rgNurbsSrf2.Points.CountU * rgNurbsSrf2.Points.CountV
                    if nPtCt  < nPtCt_Least:
                        idxPtCt_Least = i
                        nPtCt_Least = nPtCt
        return idxPtCt_Least
    
    idxPtCt_Least = surfaceWithLeastPoints()
    
    return (rgNurbsSrfs1[idxPtCt_Least], srf_devs[idxPtCt_Least]), None


def processBrepFace(rgFace0, fDevTol=0.1*sc.doc.ModelAbsoluteTolerance, bTryDegree1=True, iMaxDegree=3, iMaxCpCtEachDir=20, bPlane=False, bRev=False, bSum=True, bUniform=False, bBezier=False, bRational=True, b1DirForRational=True, bDebug=False):
    """
    """
    
    if Rhino.RhinoApp.ExeVersion < 6:
        print "This script doesn't work in Rhino versions previous to 6."
        return
    
    rgSrf0 = rgFace0.UnderlyingSurface()
    
    if isinstance(rgSrf0, rg.NurbsSurface):
        rgNurbsSrf1 = rgSrf0
    else:
        rgNurbsSrf1 = rgSrf0.ToNurbsSurface()
    
    rc = processSurface(
            rgNurbsSrf1,
            fDevTol=fDevTol,
            bTryDegree1=bTryDegree1,
            iMaxDegree=iMaxDegree,
            iMaxCpCtEachDir=iMaxCpCtEachDir,
            bPlane=bPlane,
            bRev=bRev,
            bSum=bSum,
            bUniform=bUniform,
            bBezier=bBezier,
            bRational=bRational,
            bDebug=bDebug)
    if rc[0] is None or rc[0][0] is None: return rc
    
    rgNurbsSrf_Converted, srf_dev = rc[0]
    
    # Success in creating NurbsSurface.  Now, create correctly trimmed brep.
    
    if rgFace0.IsSurface:
        rgBrep1_1Face = rgNurbsSrf_Converted.ToBrep()
        rgNurbsSrf_Converted.Dispose()
        if not rgBrep1_1Face.IsValid:
            rgBrep1_1Face.Dispose()
            return None, "Invalid brep geometry after ToBrep."
    else:
        rgBrep1_1Face = xBrepFace.retrimFace(
            rgFace0,
            rgSrf_Replacement=rgNurbsSrf_Converted,
            bEcho=False,
            bDebug=bDebug)
        rgNurbsSrf_Converted.Dispose()
        if rgBrep1_1Face is None:
            return None, "xBrepFace.retrimFace returned None."
        elif not rgBrep1_1Face.IsValid:
            rgBrep1_1Face.Dispose()
            return None, "rgBrep1_1Face is not valid."
        
    return (rgBrep1_1Face, srf_dev), None


def processBrep(rgBrep0, idxs_rgFaces, fDevTol=0.1*sc.doc.ModelAbsoluteTolerance, bShrinkFirst=True, bTryDegree1=True, iMaxDegree=3, iMaxCpCtEachDir=20, bPlane=False, bRev=False, bSum=True, bUniform=False, bBezier=False, bRational=True, b1DirForRational=True, bEcho=True, bDebug=False):
    """
    """
    
    rgBreps_1F_Mod = []
    idxs_rgFaces_Rebuilt = []
    srf_devs = []
    srf_devs_Needed = []
    
    rgBrep1 = rgBrep0.DuplicateBrep()
    
    if bShrinkFirst:
        rgBrep1.Faces.ShrinkFaces()
    
    sLogs = []
    
    sCmdPrompt0 = Rhino.RhinoApp.CommandPrompt
    iCt_Faces = len(idxs_rgFaces)
    
    for iF, idx_rgFace in enumerate(idxs_rgFaces):
        if bDebug:
            print "Processing face index {} (loop index {} of {})".format(
                    idx_rgFace, iF, iCt_Faces-1)
        elif iCt_Faces > 1:
            Rhino.RhinoApp.CommandPrompt = sCmdPrompt0 + "  Face {} of {}".format(
                    iF+1, iCt_Faces)
        
        rgFace0 = rgBrep1.Faces[idx_rgFace]
        
        rc = processBrepFace(
                rgFace0,
                fDevTol=fDevTol,
                bTryDegree1=bTryDegree1,
                iMaxDegree=iMaxDegree,
                iMaxCpCtEachDir=iMaxCpCtEachDir,
                bPlane=bPlane,
                bRev=bRev,
                bSum=bSum,
                bUniform=bUniform,
                bBezier=bBezier,
                bRational=bRational,
                b1DirForRational=b1DirForRational,
                bDebug=bDebug,
        )
        
        if rc[0] is None:
            sLogs.append(rc[1])
            continue
        
        rgBrep_1F_Converted, srf_dev = rc[0]
        if rgBrep_1F_Converted is None:
            srf_devs_Needed.append(srf_dev)
            continue
        
        rgBreps_1F_Mod.append(rgBrep_1F_Converted)
        idxs_rgFaces_Rebuilt.append(idx_rgFace)
        srf_devs.append(srf_dev)
    
    rgBrep1.Dispose()
    
    if srf_devs_Needed:
        s  = "Need tolerances of {:.2e} through {:.2e}".format(
                min(srf_devs_Needed), max(srf_devs_Needed))
        s += " to convert remaining convertible surfaces."
        sLogs.append(s)
    
    return (rgBreps_1F_Mod, idxs_rgFaces_Rebuilt, srf_devs), sLogs


def processBrepObjects(objrefs0, fDevTol=None, bShrinkFirst=None, bTryDegree1=None, iMaxDegree=None, iMaxCpCtEachDir=None, bPlane=None, bRev=None, bSum=None, bUniform=None, bBezier=None, bRational=None, b1DirForRational=None, bReplace=None, bExtract=None, bEcho=None, bDebug=None):
    """
    """
    
    for key in sOpts:
        if eval(key) is None: exec("{} = {}".format(key, Opts.values[key]))
    
    gBreps0 = []
    rdBreps0 = []
    rgBreps0 = []
    idx_rgFaces_PerBrep = []
    
    for objref0 in objrefs0:
        gBrep0 = objref0.ObjectId
        rdBrep0 = objref0.Object()
        rgBrep0 = objref0.Brep()
        
        if not rgBrep0.IsValid:
            print "Brep {} is invalid.  Fix first.".format(gBrep0)
            rgBrep0.Dispose()
            continue
        
        idx_CompIdx = objref0.GeometryComponentIndex.Index
        if idx_CompIdx == -1:
            if gBrep0 in gBreps0:
                idx_rgFaces_PerBrep[gBreps0.index(gBrep0)] = rgBrep0.Faces.Count
            else:
                gBreps0.append(gBrep0)
                rdBreps0.append(rdBrep0)
                rgBreps0.append(rgBrep0)
                idx_rgFaces_PerBrep.append(range(rgBrep0.Faces.Count))
        else:
            rgFace_Brep0 = objref0.Face()
            if gBrep0 in gBreps0:
                if rgFace_Brep0 in idx_rgFaces_PerBrep[gBreps0.index(gBrep0)]:
                    continue
                else:
                    idx_rgFaces_PerBrep[gBreps0.index(gBrep0)].append(rgFace_Brep0.FaceIndex)
            else:
                gBreps0.append(gBrep0)
                rdBreps0.append(rdBrep0)
                rgBreps0.append(rgBrep0)
                idx_rgFaces_PerBrep.append([rgFace_Brep0.FaceIndex])
    
    gBs1_perB0 = []
    srf_devs_All = []
    sLogs_All = []
    
    iCt_Breps = len(rdBreps0)
    
    for iB, (rdBrep0, rgBrep0, idxs_rgFaces) in enumerate(zip(rdBreps0, rgBreps0, idx_rgFaces_PerBrep)):
        
        Rhino.RhinoApp.CommandPrompt = "Processing brep {} of {}".format(iB+1, iCt_Breps)
        
        rc = processBrep(
                rgBrep0,
                idxs_rgFaces,
                fDevTol=fDevTol,
                bShrinkFirst=bShrinkFirst,
                bTryDegree1=bTryDegree1,
                iMaxDegree=iMaxDegree,
                iMaxCpCtEachDir=iMaxCpCtEachDir,
                bPlane=bPlane,
                bRev=bRev,
                bSum=bSum,
                bUniform=bUniform,
                bBezier=bBezier,
                bRational=bRational,
                b1DirForRational=b1DirForRational,
                bEcho=bEcho if len(gBreps0) == 1 and len(idx_rgFaces_PerBrep[0])==1 else False,
                bDebug=bDebug)
        sLogs = rc[1]
        if sLogs:
            sLogs_All.extend(sLogs)
        if not rc[0]: continue
        rgBreps_1F_Mod, idxsFs_Mod, srf_devs = rc[0]
        
        if not rgBreps_1F_Mod:
            rgBrep0.Dispose()
            continue
        
        srf_devs_All.extend(srf_devs)
        
        if bReplace:
            fTols_Edges = [edge.Tolerance for edge in rgBrep0.Edges]
            fTolerance_Join = max((
                    2.0*fDevTol,
                    1.1*max(fTols_Edges),
                    sc.doc.ModelAbsoluteTolerance))
            
            rc = xBrepObject.replaceFaces(
                    rdBrep0,
                    idxsFs_Mod,
                    rgBreps_1F_Mod,
                    bExtract=bExtract,
                    fTolerance_Join=fTolerance_Join)
            if not rc:
                if not bExtract:
                    # In case only the Join had failed.
                    gBs1_thisB0 = xBrepObject.replaceFaces(
                            rdBrep0,
                            idxsFs_Mod,
                            rgBreps_1F_Mod,
                            bExtract=True,
                            fTolerance_Join=fTolerance_Join)
                    if not rc:
                        continue
                    else:
                        print "The Join had failed," \
                            " but extract faces were replaced." \
                            "  Check the results."
                        # Variables are assigned in code below.
                else:
                    continue
            
            if bExtract:
                gBs1_thisB0, gBreps_Remaining = rc
            else:
                gBs1_thisB0 = rc
            
            if not gBs1_thisB0:
                continue
            else:
                gBs1_perB0.append(gBs1_thisB0)
        else:
            gBs1_thisB0 = []
            for rgBrep_1F_Rebuilt, idxF in zip(rgBreps_1F_Mod, idxsFs_Mod):
                gBrep1 = sc.doc.Objects.AddBrep(rgBrep_1F_Rebuilt)
                if gBrep1 != Guid.Empty:
                    gBs1_thisB0.append(gBrep1)
            gBs1_perB0.append(gBs1_thisB0)
        if bDebug or bEcho:
            if len(rgBreps0) == 1 and len(idxsFs_Mod)==1:
                s  = getNurbsSurfaceChangeDescription(
                        rgBrep0.Faces[idxsFs_Mod[0]].UnderlyingSurface(),
                        rgBreps_1F_Mod[0].Surfaces[0])
                s += "  Deviation: {:.2e}".format(srf_devs_All[0])
                print s
        
        for b in rgBreps_1F_Mod: b.Dispose()
        rgBrep0.Dispose()
        if gBs1_perB0 and (bDebug or bEcho):
            if bReplace:
                print "{} faces replaced in brep.".format(len(idxsFs_Mod))
            else:
                print "{} monoface breps added.".format(len(gBs1_thisB0))
    
    if gBs1_perB0 and (bDebug or bEcho):
        if not (len(rgBreps0) == 1 and len(idxsFs_Mod)==1):
            print "Maximum deviations: [{:.2e},{:.2e}]".format(min(srf_devs_All), max(srf_devs_All))
    
    if bExtract or not bReplace:
        [sc.doc.Objects.Select(objectId=g) for gs in gBs1_perB0 for g in gs]
    
    return (gBs1_perB0, srf_devs_All), sLogs_All


def main():
    
    rc = getInput()
    if rc is None: return
    (
            objrefs0,
            fDevTol,
            bShrinkFirst,
            bTryDegree1,
            iMaxDegree,
            iMaxCpCtEachDir,
            bPlane,
            bRev,
            bSum,
            bUniform,
            bBezier,
            bRational,
            b1DirForRational,
            bReplace,
            bExtract,
            bEcho,
            bDebug,
    ) = rc
    
    if not bDebug:
        sc.doc.Views.RedrawEnabled = False
    
    rc = processBrepObjects(
            objrefs0=objrefs0,
            fDevTol=fDevTol,
            bShrinkFirst=bShrinkFirst,
            bTryDegree1=bTryDegree1,
            iMaxDegree=iMaxDegree,
            iMaxCpCtEachDir=iMaxCpCtEachDir,
            bPlane=bPlane,
            bRev=bRev,
            bSum=bSum,
            bUniform=bUniform,
            bBezier=bBezier,
            bRational=bRational,
            b1DirForRational=b1DirForRational,
            bReplace=bReplace,
            bExtract=bExtract,
            bEcho=bEcho,
            bDebug=bDebug,
    )
    (gBs1_perB0, srf_devs_All), sLogs = rc
    
    for sLog in set(sLogs):
        print "[{}] {}".format(sLogs.count(sLog), sLog)
    
    if gBs1_perB0 and (bDebug or bEcho):
        print "Maximum deviations: [{:.2e},{:.2e}]".format(min(srf_devs_All), max(srf_devs_All))
    
    sc.doc.Views.RedrawEnabled = True


if __name__ == '__main__': main()