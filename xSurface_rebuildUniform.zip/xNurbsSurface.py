"""
181129: Created.
190201: Bug fixes in isKnotVectorUniform.
190310: Added createWithDifferentPointLocations and duplicateWithDifferentPointLocations.
190409: Removed, but readded function.
190510: Added a function.
190720: Added a function.
"""

import Rhino
import Rhino.Geometry as rg


def areEqual(rgNurbsSrfs, epsilon=1e-9, bDebug=False):
    """
    """
    
    if len(rgNurbsSrfs) < 2: return
    
    for rgNurbsSrf in rgNurbsSrfs:
        if not isinstance(rgNurbsSrf, rg.NurbsSurface):
            return
        if not rgNurbsSrf.IsValid:
            return
    
    rgNurbsSrfA = rgNurbsSrfs[0]
    for i in xrange(1, len(rgNurbsSrfs)):
        rgNurbsSrfB = rgNurbsSrfs[i]
        
        if rgNurbsSrfA.IsRational != rgNurbsSrfB.IsRational:
            return False
        
        if rgNurbsSrfA.IsSolid != rgNurbsSrf.IsSolid:
            return False
        
        if rgNurbsSrfA.OrderU != rgNurbsSrf.OrderU:
            return False
        
        if rgNurbsSrfA.OrderV != rgNurbsSrf.OrderV:
            return False
        
        if rgNurbsSrfA.Points.CountU != rgNurbsSrfB.Points.CountU:
            return False
        
        if rgNurbsSrfA.Points.CountV != rgNurbsSrfB.Points.CountV:
            return False
        
        if not rgNurbsSrfA.Points.EpsilonEquals(rgNurbsSrfB.Points, epsilon=epsilon):
            return False
        
        if rgNurbsSrfA.KnotsU.Count != rgNurbsSrfB.KnotsU.Count:
            return False
        
        if rgNurbsSrfA.KnotsV.Count != rgNurbsSrfB.KnotsV.Count:
            return False
        
        if not rgNurbsSrfA.KnotsU.EpsilonEquals(rgNurbsSrfB.KnotsU, epsilon=epsilon):
            return False
        
        if not rgNurbsSrfA.KnotsV.EpsilonEquals(rgNurbsSrfB.KnotsV, epsilon=epsilon):
            return False
        
        #        for kA, kB in zip(rgNurbsSrfA.KnotsU, rgNurbsSrfB.KnotsU):
        #            if abs(kA - kB) > epsilon:
        #                return False
        #        
        #        for kA, kB in zip(rgNurbsSrfA.KnotsV, rgNurbsSrfB.KnotsV):
        #            if abs(kA - kB) > epsilon:
        #                return False
        
        return True


def createWithDifferentPointLocations(ns0, pts_cp_ns0):
    """Started with code from rhinoscript\surface.py.
    
    Is there any way to modify this to make it useful since duplicateWithDifferentPointLocations does the same?
    
    Parameters:
    Returns:
    """
    
    points0 = ns0.Points
    
    ns1 = rg.NurbsSurface.Create(
            dimension=3,
            isRational=ns0.IsRational,
            order0=ns0.OrderU,
            order1=ns0.OrderV,
            controlPointCount0=points0.CountU,
            controlPointCount1=points0.CountV,
    )
    #add the pts_cp_ns0 and weights
    controlpoints = ns1.Points
    index = 0
    for iU in xrange(points0.CountU):
        for iV in xrange(points0.CountV):
            if ns0.IsRational:
                cp = rg.ControlPoint(pts_cp_ns0[index], ns0.GetWeight(iU,iV))
                controlpoints.SetControlPoint(iU,iV,cp)
            else:
                cp = rg.ControlPoint(pts_cp_ns0[index])
                controlpoints.SetControlPoint(iU,iV,cp)
            index += 1
    #add the knots
    for iU in xrange(ns0.KnotsU.Count): ns1.KnotsU[iU] = ns0.KnotsU[iU]
    for iU in xrange(ns0.KnotsV.Count): ns1.KnotsV[iU] = ns0.KnotsV[iU]
    if not ns1.IsValid:
        print "NurbsSurface is not valid."
        return
    return ns1


def duplicateWithDifferentPointLocations(ns0, pts_cp_ns0):
    ns1 = ns0.Duplicate()
    for iV in xrange(ns1.Points.CountV):
        for iU in xrange(ns1.Points.CountU):
            cp_ns1 = ns1.Points.GetControlPoint(u=iU, v=iV)
            cp_ns1.Location = pts_cp_ns0[iU*ns1.Points.CountV+iV]
            ns1.Points.SetControlPoint(u=iU, v=iV, cp=cp_ns1)
    return ns1


def isKnotVectorUniform(rgNurbsSrf, iDirection):
    
    if rgNurbsSrf.GetType() != rg.NurbsSurface: return
    
    degree = rgNurbsSrf.Degree(iDirection)
    knots = (rgNurbsSrf.KnotsU, rgNurbsSrf.KnotsV)[iDirection]
    
    # Set up for loop's range's start and stop based on whether surface is periodic in this iDirection.
    # iKnot_Start: Start of spans to check.
    # iKnot_End: End of spans to check.
    if rgNurbsSrf.IsPeriodic(iDirection):
        iKnot_Start = 0
        iKnot_End = knots.Count
    else: 
        iKnot_Start = degree
        iKnot_End = knots.Count-degree
        if iKnot_Start == iKnot_End: return True # Is this also true when periodic?
    
    for i in range(iKnot_Start, iKnot_End+1):
        
        # A uniform knot vector does not have duplicate interior knot parameters.
        if i != iKnot_Start and i != iKnot_End:
            if knots.KnotMultiplicity(i) != 1: return False
        
        #  A uniform knot vector's interior parameter spans are all equal.
        if i == iKnot_Start:
            # Record first knot vector span and use for comparison with other spans.
            knotVect1stSpan = knots[i] - knots[i-1]
        else:
            if not Rhino.RhinoMath.EpsilonEquals(knots[i] - knots[i-1],
                    knotVect1stSpan,
                    Rhino.RhinoMath.ZeroTolerance):
                return False
    
    return True


def rebuildUniform(rgNurbsSrf0, uDegree, vDegree, uPointCount, vPointCount):
    """NurbsSurface.Rebuild then sets the domains as the original NurbsSurface."""
    rgNurbsSrf1 = rgNurbsSrf0.Rebuild(uDegree, vDegree, uPointCount, vPointCount)
    if rgNurbsSrf1 is None: return
    rgNurbsSrf1.SetDomain(direction=0, domain=rgNurbsSrf0.Domain(0))
    rgNurbsSrf1.SetDomain(direction=1, domain=rgNurbsSrf0.Domain(1))
    return rgNurbsSrf1

